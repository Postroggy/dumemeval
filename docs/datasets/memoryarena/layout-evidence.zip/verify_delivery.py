"""Recheck relocated evidence, baseline diagnostics and the built wheel."""

import ast
import hashlib
import json
import os
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CHECKS = Path(__file__).resolve().parent
DOCS = ROOT / 'docs/datasets/memoryarena'
mapping = json.loads((CHECKS / 'path-map.json').read_text(encoding='utf-8'))

tracked = subprocess.check_output(['git', 'ls-files'], cwd=ROOT, text=True).splitlines()
def content_hash(name):
    # These inputs are Git text files. Normalize checkout line endings to blob bytes.
    return hashlib.sha256((ROOT / name).read_bytes().replace(b'\r\n', b'\n')).hexdigest()

source_hashes = {
    name: content_hash(name) for name in tracked
    if name.startswith(('src/', 'tests/')) and name.endswith('.py')
}
source_tree_sha256 = hashlib.sha256(json.dumps(source_hashes, sort_keys=True).encode()).hexdigest()
input_paths = set((CHECKS / 'changed-paths.txt').read_text(encoding='utf-8-sig').splitlines())
input_paths = {name for name in input_paths if name.endswith('.py') or name == 'tests/benchmarks/memoryarena/fixtures/cases.json'}
input_paths.update(name for name in tracked if name.startswith('configs/memoryarena/'))
input_paths.update({'pyproject.toml', 'uv.lock'})
input_hashes = {name: content_hash(name) for name in sorted(input_paths)}
published = DOCS / 'layout-verification.json'
if published.exists():
    recorded = json.loads(published.read_text(encoding='utf-8'))
    assert recorded['tested_source_tree_sha256'] == source_tree_sha256
    assert recorded['inputs_sha256'] == input_hashes

def checks(data):
    return {
        node.attrib['classname'] + '::' + node.attrib['name']: (
            'failed' if node.find('failure') is not None or node.find('error') is not None
            else 'skipped' if node.find('skipped') is not None else 'passed'
        ) for node in ET.fromstring(data).iter('testcase')
    }

def diagnostics(data):
    result = Counter()
    for line in data.decode('utf-8-sig').splitlines():
        match = re.match(r'(.+?):\d+(?::\d+)?: error: (.+)', line)
        if match:
            path = match[1].replace('\\', '/')
            result[(mapping.get(path, path), match[2])] += 1
    return result

current = checks((CHECKS / 'pytest-current.xml').read_bytes())
with zipfile.ZipFile(DOCS / 'control-completeness-evidence.zip') as bundle:
    previous = checks(bundle.read('checks/pytest-current.xml'))
    previous_types = diagnostics(bundle.read('checks/mypy-current.log'))
with zipfile.ZipFile(DOCS / 'review-evidence.zip') as bundle:
    upstream = checks(bundle.read('baseline/pytest-baseline.xml'))
    upstream_types = diagnostics(bundle.read('baseline/mypy-baseline.log'))
current_types = diagnostics((CHECKS / 'mypy-current.log').read_bytes())
# Failed tests did not move. Compare exact test identity and type-message multiplicity.
failures = {name for name, status in current.items() if status == 'failed'}
old_failures = {name for name, status in previous.items() if status == 'failed'}
upstream_failures = {name for name, status in upstream.items() if status == 'failed'}
assert failures == old_failures and not failures - upstream_failures
assert current_types == previous_types and not current_types - upstream_types
related = {name: status for name, status in current.items() if name.startswith((
    'tests.benchmarks.memoryarena.', 'tests.test_environment_extensions',
    'tests.test_control_completeness', 'tests.test_experiment_controls', 'tests.test_scoring_checkpoint',
))}
official = {name: status for name, status in current.items() if name.startswith('tests.benchmarks.memoryarena.test_official_parity')}
assert set(related.values()) == {'passed'} and len(official) == 33

historical = []
for old, expected in json.loads((CHECKS / 'historical-sha256.json').read_text()).items():
    new = mapping[old]
    actual = hashlib.sha256((ROOT / new).read_bytes()).hexdigest()
    assert actual == expected, old
    historical.append({'before': old, 'after': new, 'working_bytes_sha256': actual})

# The distribution must include every moved source and both standalone worker files.
wheel = next((CHECKS / 'dist').glob('*.whl'))
installed = (CHECKS / ('installed-' + hashlib.sha256(wheel.read_bytes()).hexdigest()[:12])).resolve()
assert installed.is_relative_to(CHECKS.resolve())
installed.mkdir(exist_ok=True)
with zipfile.ZipFile(wheel) as package:
    entries = set(package.namelist())
    for source in (ROOT / 'src/dumemeval/benchmarks').rglob('*.py'):
        member = source.relative_to(ROOT / 'src').as_posix()
        assert member in entries
        assert package.read(member).replace(b'\r\n', b'\n') == source.read_bytes().replace(b'\r\n', b'\n')
    assert 'dumemeval/task_environments/agent_tool.py' in entries
    assert 'dumemeval/task_environments/prepare.py' in entries
    for name in entries:
        assert (installed / name).resolve().is_relative_to(installed), name
    package.extractall(installed)

# Run the same import-order regressions against installed wheel files, outside the checkout.
test_module = ROOT / 'tests/benchmarks/memoryarena/test_layout.py'
tree = ast.parse(test_module.read_text(encoding='utf-8'))
scripts = {}
for fn in tree.body:
    if isinstance(fn, ast.FunctionDef):
        assignment = next(n for n in fn.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'script' for t in n.targets))
        scripts[fn.name] = ast.literal_eval(assignment.value)
environment = {**os.environ, 'PYTHONPATH': str(installed), 'PYTHONUTF8': '1'}
guard = 'import dumemeval; from pathlib import Path; assert Path(dumemeval.__file__).resolve().is_relative_to(Path.cwd()), dumemeval.__file__\n'
for first in (
    'dumemeval.benchmarks.memoryarena.datasets.shopping',
    'dumemeval.benchmarks.memoryarena.metrics.travel',
    'dumemeval.benchmarks.memoryarena.environment.providers',
    'dumemeval.benchmarks.memoryarena.environment.runtime',
):
    subprocess.run([sys.executable, '-c', guard + scripts['test_direct_import_and_registries_without_optional_worker_sdks'], first], cwd=installed, env=environment, check=True, capture_output=True, text=True, timeout=60)
subprocess.run([sys.executable, '-c', guard + scripts['test_lazy_builtins_preserve_previously_registered_overrides']], cwd=installed, env=environment, check=True, capture_output=True, text=True, timeout=60)
subprocess.run([sys.executable, str(installed / 'dumemeval/task_environments/agent_tool.py'), '--help'], cwd=installed, env=environment, check=True, capture_output=True, text=True, timeout=30)
# A real installed official worker is started and reaped; these tool actions never call a model.
worker_test = '''
from pathlib import Path
from dumemeval.benchmarks.memoryarena.environment.client import ArenaClient
from dumemeval.benchmarks.memoryarena.environment.config import ArenaConnection, ArenaRuntimeConfig
from dumemeval.benchmarks.memoryarena.environment.service import OfficialService
config = ArenaRuntimeConfig(reference=Path(__import__('os').environ['MEMORYARENA_REFERENCE']), env_name='math', service_env={'ANTHROPIC_API_KEY':'fixture-never-called'})
service = OfficialService(config, Path('worker-proof'))
try:
    service.start()
    client = ArenaClient(ArenaConnection(base_url=service.url, env_name='math', env_config={'backend':'anthropic', 'model_name':'fixture-never-called'}))
    import time
    for attempt in range(100):
        try:
            client.available()
            break
        except RuntimeError:
            time.sleep(0.1)
    with client:
        assert client.reset(seed=17).observation['step'] == 0
        assert client.step({'type':'final','answer':'2'}).observation['final'] == '2'
        assert client.tools()
finally:
    service.close()
assert service.process is None
'''
environment['MEMORYARENA_REFERENCE'] = os.environ.get('MEMORYARENA_REFERENCE', str(ROOT / '.cache/memoryarena'))
subprocess.run([sys.executable, '-c', guard + worker_test], cwd=installed, env=environment, check=True, capture_output=True, text=True, timeout=60)

report = {
    'tested_source_tree_sha256': source_tree_sha256,
    'tested_python_files': len(source_hashes),
    'inputs_sha256': input_hashes,
    'parent_commit': '8811040c66bfe745d53ff11fb811e495758b5421',
    'upstream_commit': '37a0e1959e14509898fca856d8fd3fd2a720aefb',
    'current': dict(Counter(current.values())),
    'previous': dict(Counter(previous.values())),
    'upstream': dict(Counter(upstream.values())),
    'related': dict(Counter(related.values())),
    'official_parity': dict(Counter(official.values())),
    'failure_identities_unchanged': failures == old_failures,
    'new_failures_from_upstream': sorted(failures - upstream_failures),
    'mypy': {'current_errors': sum(current_types.values()), 'files': len({key[0] for key in current_types}), 'same_as_parent': current_types == previous_types, 'new_diagnostics_from_upstream': sum((current_types - upstream_types).values())},
    'moved_paths': mapping,
    'historical_bytes_preserved': historical,
    'wheel': {'file': wheel.name, 'sha256': hashlib.sha256(wheel.read_bytes()).hexdigest(), 'source_modules_checked': len(list((ROOT / 'src/dumemeval/benchmarks').rglob('*.py'))), 'isolated_import_checks': 5, 'agent_client_help': 'passed', 'official_worker_lifecycle': 'passed'},
}
(CHECKS / 'verification.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps({key: value for key, value in report.items() if key not in {'moved_paths', 'historical_bytes_preserved', 'inputs_sha256'}}, indent=2))
