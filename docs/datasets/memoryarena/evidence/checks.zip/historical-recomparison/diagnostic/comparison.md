# DuMemEval 对比（vs baseline）

> off=.cache\pr5-control-completeness-20260916\hermes\inputs\diagnostic\off · on=.cache\pr5-control-completeness-20260916\hermes\inputs\diagnostic\on

## Runs

| run | tasks | benchmark | judge | git |
|---|---|---|---|---|
| off（baseline） | 1 | - | n/a×1 | `909e185` |
| on | 1 | - | n/a×1 | `909e185` |

## Metrics

| metric | off | on | Δ vs baseline |
|---|---|---|---|
| `efficiency.cost_usd` | 0.0000 | 0.0000 | on: +0.0000 ↓ |
| `efficiency.tokens_in` | 0.0000 | 0.0000 | on: +0.0000 ↓ |
| `efficiency.tokens_out` | 0.0000 | 0.0000 | on: +0.0000 ↓ |
| `trace.empty_output_rate` | 0.0000 | 0.0000 | on: +0.0000 ↓ |
| `trace.error_rate` | 0.0000 | 0.0000 | on: +0.0000 ↓ |
| `trace.memory_observation_coverage` | 0.0000 | 1.0000 | on: +1.0000 ↑ |
| `trace.memory_tool_used_rate` | - | 1.0000 | on: - |
| `trace.trace_captured_rate` | 1.0000 | 1.0000 | on: +0.0000 ↓ |
| `utility.success_rate` | 1.0000 | 1.0000 | on: +0.0000 ↓ |
| `utility.turns` | 2.0000 | 2.0000 | on: +0.0000 ↓ |

## Warnings（可比性）

- Required control fingerprints are missing for off: agent_skills, observed_prompts; experiment comparability is unverified
- Required control fingerprints are missing for on: agent_skills, observed_prompts; experiment comparability is unverified
