Issue #4 acceptance evidence index
f3fdd92/: final implementation check logs, before documentation consolidation.
baseline/: recorded upstream 37a0e19 checks, not a new baseline run.
environment-probes/: corrected Shopping episode boundary and official tool traces.
setup/: existing isolated install / image / worker verification.
historical-recomparison/: legacy reports warn about missing control fingerprints.
manifests/: original provenance and checksum lists; paths refer to their recorded revisions.
origins.json: source archive/member and checksum for each retained check record.
Archived member bytes are unchanged. Current run commands are in ../clean-setup.md.
