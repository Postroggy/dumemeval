# memoryarena_travel_1 — memoryarena-on

memory_session_transfer | claude-code | directory
status: completed

```bash
uv run python -m dumemeval run --config .cache/memoryarena-repro/travel-real-20260919-final.yaml --output results\memoryarena\travel-real-20260919-final\on
```

- git: `b4fa376 (codex/memoryarena-issue-4) dirty`
- judging: type=llm_judge model=gpt-5.5(medium) num_runs=1 skip_failed=False


## Quality
- precision: 1.000
- recall: 1.000
- judge: 1/1 完成

## Utility
- task_success: True
- success_rate: 1.000

## Benchmark (memoryarena_travel)

Pinned Travel offline evaluator: six-slot PS/SPS/SR percentages.
- PS: 100.0000
- SPS: 100.0000
- SR: 100.0000

## Metrics
- quality.precision: 1.0000
- quality.recall: 1.0000
- quality.hallucination_rate: 0.0000
- quality.omission_rate: 0.0000
- utility.task_success: 1.0000
- utility.success_rate: 1.0000
- utility.turns: 8.0000
- utility.cost_usd: 0.0000
- utility.memory_conditioned_gain: 0.0000
- efficiency.write_latency_ms: 0.0000
- efficiency.retrieval_latency_ms: 0.0800
- efficiency.tokens_in: 1528310.0000
- efficiency.tokens_out: 15082.0000
- efficiency.cost_usd: 4.8112
- trace.trace_captured_rate: 1.0000
- trace.empty_output_rate: 0.0000
- trace.error_rate: 0.0000
- trace.memory_tool_used: 1.0000
- trace.memory_write_ops: 17.0000
- trace.memory_read_ops: 33.0000

Memory observations (lower bounds): writes=17, reads=33. n/a means unmeasured; missing observations do not establish zero use.

## Sessions

| Session | Execution | Environment | Error |
| --- | --- | --- | --- |
| 1 | completed | step |  |
| 2 | completed | step |  |
| 3 | completed | step |  |
| 4 | completed | step |  |
| 5 | completed | step |  |
| 6 | completed | step |  |
| 7 | completed | step |  |
| 8 | completed | step |  |

## Artifacts

- agent_trajectory: `results\memoryarena\travel-real-20260919-final\on\trials\dumemeval_memoryarena_travel_1__session_8\agent\trajectory.json`
- environment_trace: `results\memoryarena\travel-real-20260919-final\on\environments\memoryarena_travel_1-8a5d43ea\trace.json`
- environment_journal: `results\memoryarena\travel-real-20260919-final\on\environments\memoryarena_travel_1-8a5d43ea\trace.jsonl`
- environment_provenance: `results\memoryarena\travel-real-20260919-final\on\environments\memoryarena_travel_1-8a5d43ea\runtime.json`