# DuMemEval 对比（vs baseline）

> off=results\memoryarena\travel-real-20260919-final\off · on=results\memoryarena\travel-real-20260919-final\on

## Runs

| run | tasks | benchmark | judge | git |
|---|---|---|---|---|
| off（baseline） | 1 | memoryarena_travel | gpt-5.5(medium)×1 | `b4fa376` |
| on | 1 | memoryarena_travel | gpt-5.5(medium)×1 | `b4fa376` |

## Metrics

| metric | off | on | Δ vs baseline |
|---|---|---|---|
| `efficiency.cost_usd` | 3.6058 | 4.8112 | on: +1.2053 ↓ |
| `efficiency.tokens_in` | 1153685.0000 | 1528310.0000 | on: +374625.0000 ↓ |
| `efficiency.tokens_out` | 9651.0000 | 15082.0000 | on: +5431.0000 ↓ |
| `memoryarena_travel.PS` | 87.5000 | 100.0000 | on: +12.5000 ↑ |
| `memoryarena_travel.SPS` | 100.0000 | 100.0000 | on: +0.0000 ↓ |
| `memoryarena_travel.SR` | 0.0000 | 100.0000 | on: +100.0000 ↑ |
| `quality.precision` | 0.0000 | 1.0000 | on: +1.0000 ↑ |
| `quality.recall` | 0.0000 | 1.0000 | on: +1.0000 ↑ |
| `trace.empty_output_rate` | 0.0000 | 0.0000 | on: +0.0000 ↓ |
| `trace.error_rate` | 0.0000 | 0.0000 | on: +0.0000 ↓ |
| `trace.memory_observation_coverage` | 0.0000 | 1.0000 | on: +1.0000 ↑ |
| `trace.memory_tool_used_rate` | - | 1.0000 | on: - |
| `trace.trace_captured_rate` | 1.0000 | 1.0000 | on: +0.0000 ↓ |
| `utility.success_rate` | 1.0000 | 1.0000 | on: +0.0000 ↓ |
| `utility.turns` | 8.0000 | 8.0000 | on: +0.0000 ↓ |

## Warnings（可比性）

- Controlled input differs: observed_prompts; this comparison is not a controlled ablation
- Controlled input differs: tasks; this comparison is not a controlled ablation
