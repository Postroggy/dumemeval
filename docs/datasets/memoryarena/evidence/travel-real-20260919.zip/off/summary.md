# DuMemEval 汇总 — memoryarena-travel-off

> 2026-09-19 13:14:15 · 1 tasks · 并行度 1

## Reproduce

```bash
uv run python -m dumemeval run --config .cache/memoryarena-repro/travel-real-20260919-final.yaml --output results\memoryarena\travel-real-20260919-final\off
```

- git: `b4fa376 (codex/memoryarena-issue-4) dirty`
- judging: type=llm_judge model=gpt-5.5(medium) num_runs=1 skip_failed=False

## Benchmark[memoryarena_travel]（pooled，官方口径）

Pinned Travel offline evaluator: six-slot PS/SPS/SR percentages.

| 指标 | 值 |
|---|---|
| PS | 87.5000 |
| SPS | 100.0000 |
| SR | 0.0000 |

## 跨 task 平均

- Quality: recall=0.000 precision=0.000
- Utility: success_rate=1.000

## Per-task

| task | sessions | benchmark | 报告 |
|---|---|---|---|
| memoryarena_travel_1 | 8/8 | 87.500 | `results\memoryarena\travel-real-20260919-final\off\memoryarena_travel_1__memoryarena-off` |

## Warnings

- Pinned Travel offline evaluator: six-slot PS/SPS/SR percentages.
