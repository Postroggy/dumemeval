# memoryarena_travel_1 — memoryarena-off

test_only | claude-code | none
status: completed

```bash
uv run python -m dumemeval run --config .cache/memoryarena-repro/travel-real-20260919-final.yaml --output results\memoryarena\travel-real-20260919-final\off
```

- git: `b4fa376 (codex/memoryarena-issue-4) dirty`
- judging: type=llm_judge model=gpt-5.5(medium) num_runs=1 skip_failed=False


## Quality
- precision: 0.000
- recall: 0.000
- judge: 1/1 完成

## Utility
- task_success: True
- success_rate: 1.000

## Benchmark (memoryarena_travel)

Pinned Travel offline evaluator: six-slot PS/SPS/SR percentages.
- PS: 87.5000
- SPS: 100.0000
- SR: 0.0000

## Metrics
- quality.precision: 0.0000
- quality.recall: 0.0000
- quality.hallucination_rate: 0.0000
- quality.omission_rate: 1.0000
- utility.task_success: 1.0000
- utility.success_rate: 1.0000
- utility.turns: 8.0000
- utility.cost_usd: 0.0000
- utility.memory_conditioned_gain: 0.0000
- efficiency.write_latency_ms: 0.0000
- efficiency.retrieval_latency_ms: 0.0000
- efficiency.tokens_in: 1153685.0000
- efficiency.tokens_out: 9651.0000
- efficiency.cost_usd: 3.6058
- trace.trace_captured_rate: 1.0000
- trace.empty_output_rate: 0.0000
- trace.error_rate: 0.0000

Memory observations (lower bounds): writes=n/a, reads=n/a. n/a means unmeasured; missing observations do not establish zero use.

## Sessions

| Session | Execution | Environment | Error |
| --- | --- | --- | --- |
| 1 | completed | step |  |
| 2 | completed | step |  |
| 3 | completed | step |  |
| 4 | completed | step |  |
| 5 | completed | step |  |
| 6 | completed | step |  |
| 7 | completed | step |  |
| 8 | completed | step |  |

## Artifacts

- agent_trajectory: `results\memoryarena\travel-real-20260919-final\off\trials\dumemeval_memoryarena_travel_1__session_8\agent\trajectory.json`
- environment_trace: `results\memoryarena\travel-real-20260919-final\off\environments\memoryarena_travel_1-8a5d43ea\trace.json`
- environment_journal: `results\memoryarena\travel-real-20260919-final\off\environments\memoryarena_travel_1-8a5d43ea\trace.jsonl`
- environment_provenance: `results\memoryarena\travel-real-20260919-final\off\environments\memoryarena_travel_1-8a5d43ea\runtime.json`