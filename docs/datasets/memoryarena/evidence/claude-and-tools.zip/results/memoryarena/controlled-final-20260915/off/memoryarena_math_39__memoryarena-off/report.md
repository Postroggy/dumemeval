# memoryarena_math_39 — memoryarena-off

status: completed

## Benchmark (memoryarena_math)
- is_correct: 1.0000
- avg_progress_score: 1.0000
- overall_average_passrate: 1.0000

## Metrics
- utility.task_success: 1.0000
- utility.success_rate: 1.0000
- utility.turns: 2.0000
- utility.cost_usd: 0.0000
- utility.memory_conditioned_gain: 0.0000
- efficiency.write_latency_ms: 0.0000
- efficiency.retrieval_latency_ms: 0.0000
- efficiency.tokens_in: 250315.0000
- efficiency.tokens_out: 1298.0000
- efficiency.cost_usd: 0.7704
- trace.trace_captured_rate: 1.0000
- trace.empty_output_rate: 0.0000
- trace.error_rate: 0.0000

Memory observations (lower bounds): writes=n/a, reads=n/a. n/a means unmeasured; missing observations do not establish zero use.

## Sessions

| Session | Execution | Environment | Error |
| --- | --- | --- | --- |
| 1 | completed | step |  |
| 2 | completed | step |  |

## Artifacts

- agent_trajectory: `results\memoryarena\controlled-final-20260915\off\trials\dumemeval_memoryarena_math_39__session_2\agent\trajectory.json`
- environment_trace: `results\memoryarena\controlled-final-20260915\off\environments\memoryarena_math_39-a2b06cb5\trace.json`
- environment_provenance: `results\memoryarena\controlled-final-20260915\off\environments\memoryarena_math_39-a2b06cb5\runtime.json`

## Reproduce

```bash
uv run python -m dumemeval run --config configs/memoryarena/controlled-math.yaml --output results\memoryarena\controlled-final-20260915\off
```

- git: `37a0e19 (codex/memoryarena-issue-4) dirty`
- judging: type=llm_judge model=gpt-5.5(medium) num_runs=1 skip_failed=False
