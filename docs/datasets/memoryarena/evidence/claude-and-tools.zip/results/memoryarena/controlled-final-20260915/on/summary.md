# DuMemEval 汇总 — memoryarena-math-controlled-on

> 2026-09-15 02:27:28 · 1 tasks · 并行度 1

## Reproduce

```bash
uv run python -m dumemeval run --config configs/memoryarena/controlled-math.yaml --output results\memoryarena\controlled-final-20260915\on
```

- git: `37a0e19 (codex/memoryarena-issue-4) dirty`
- judging: type=llm_judge model=gpt-5.5(medium) num_runs=1 skip_failed=False

## Benchmark[memoryarena_math]（pooled，官方口径）

| 指标 | 值 |
|---|---|
| overall_average_passrate | 1.0000 |
| avg_progress_score | 1.0000 |
| is_correct | 1.0000 |

## 跨 task 平均

- Quality: n/a（未配 ground truth）
- Utility: success_rate=1.000

## Per-task

| task | sessions | benchmark | 报告 |
|---|---|---|---|
| memoryarena_math_39 | 2/2 | 1.000 | `results\memoryarena\controlled-final-20260915\on\memoryarena_math_39__memoryarena-on` |
