# DuMemEval 对比（vs baseline）

> off=results\memoryarena\controlled-final-20260915\off · on=results\memoryarena\controlled-final-20260915\on

## Runs

| run | tasks | benchmark | judge | git |
|---|---|---|---|---|
| off（baseline） | 1 | memoryarena_math | gpt-5.5(medium)×1 | `37a0e19` |
| on | 1 | memoryarena_math | gpt-5.5(medium)×1 | `37a0e19` |

## Metrics

| metric | off | on | Δ vs baseline |
|---|---|---|---|
| `efficiency.cost_usd` | 0.7704 | 1.0462 | on: +0.2758 ↓ |
| `efficiency.tokens_in` | 250315.0000 | 339674.0000 | on: +89359.0000 ↓ |
| `efficiency.tokens_out` | 1298.0000 | 1812.0000 | on: +514.0000 ↓ |
| `memoryarena_math.avg_progress_score` | 1.0000 | 1.0000 | on: +0.0000 ↓ |
| `memoryarena_math.is_correct` | 1.0000 | 1.0000 | on: +0.0000 ↓ |
| `memoryarena_math.overall_average_passrate` | 1.0000 | 1.0000 | on: +0.0000 ↓ |
| `trace.empty_output_rate` | 0.0000 | 0.0000 | on: +0.0000 ↓ |
| `trace.error_rate` | 0.0000 | 0.0000 | on: +0.0000 ↓ |
| `trace.memory_observation_coverage` | 0.0000 | 1.0000 | on: +1.0000 ↑ |
| `trace.memory_tool_used_rate` | - | 1.0000 | on: - |
| `trace.trace_captured_rate` | 1.0000 | 1.0000 | on: +0.0000 ↓ |
| `utility.success_rate` | 1.0000 | 1.0000 | on: +0.0000 ↓ |
| `utility.turns` | 2.0000 | 2.0000 | on: +0.0000 ↓ |
