"""Reproducible source preparation and explicit missing-asset diagnostics."""

from __future__ import annotations

import glob
import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

from pydantic import BaseModel, Field

from ..core.config import ExperimentConfig
from ..models.environment import ArenaRuntimeConfig
from .service import verify_reference


class PreparationReport(BaseModel):
    ready: bool = False
    reference: str
    revision: str
    scene: str
    sources: dict[str, str] = Field(default_factory=dict)
    assets: dict[str, str] = Field(default_factory=dict)
    missing: list[str] = Field(default_factory=list)


def checksum(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def required_assets(config: ArenaRuntimeConfig) -> list[str]:
    if config.env_name == "travel_planner":
        root = Path(
            str(
                config.tools_config.get("database")
                or config.reference / "env/env_systems/travel_planner_env/database"
            )
        )
        return [
            str(root / path)
            for path in (
                "flights/clean_Flights_2022.csv",
                "restaurants/clean_restaurant_2022.csv",
                "accommodations/clean_accommodations_2022.csv",
                "attractions/attractions.csv",
                "googleDistanceMatrix/distance.csv",
                "background/citySet_with_states.txt",
            )
        ]
    if config.env_name == "webshop":
        root = Path(
            config.service_env.get("MEMORYARENA_WEBSHOP_DATA_ROOT", str(config.reference / "data/shopping"))
        )
        return [
            config.service_env.get("MEMORYARENA_WEBSHOP_ITEMS_FILE", str(root / "items_shuffle.json")),
            *[
                str(root / path)
                for path in (
                    "items_ins_v2.json",
                    "domain_data.json",
                    "product_catalog/*.json",
                    "search_engine/indexes-full/*",
                )
            ],
        ]
    if config.env_name == "browsecomp-plus":
        args = config.tools_config.get("searcher_args")
        if not isinstance(args, dict):
            return ["Search requires tools_config.searcher_args"]
        keys = (
            ("index_path",)
            if config.tools_config.get("searcher_type") == "bm25"
            else ("index_path", "id_map_path", "corpus_path")
        )
        assets = [str(args.get(key, f"Missing {key}")) for key in keys]
        if config.tools_config.get("snippet_max_tokens", 512) > 0:
            cache = config.service_env.get("HF_HUB_CACHE")
            revision = config.tools_config.get("tokenizer_revision")
            if not cache or not revision:
                assets.append("Search snippets require HF_HUB_CACHE and tools_config.tokenizer_revision")
            else:
                model = Path(cache) / "models--Qwen--Qwen3-0.6B"
                assets.extend([str(model / "refs/main"), str(model / "snapshots" / str(revision))])
        return assets
    return []


def inspect_environment(config: ArenaRuntimeConfig, *, clone: bool = False) -> PreparationReport:
    reference = config.reference.resolve()
    report = PreparationReport(reference=str(reference), revision=config.revision, scene=config.env_name)
    if not reference.exists() and clone:
        reference.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run(
            ["git", "clone", "https://github.com/ZexueHe/MemoryArena.git", str(reference)],
            check=True,
            timeout=300,
        )
        subprocess.run(
            ["git", "-C", str(reference), "checkout", "--detach", config.revision], check=True, timeout=60
        )
    try:
        report.sources = verify_reference(reference, config.revision)
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        report.missing.append(f"Official source verification failed: {type(exc).__name__}")
    for pattern in required_assets(config):
        files = []
        for name in glob.glob(pattern):
            path = Path(name)
            files.extend([path] if path.is_file() else [p for p in path.rglob("*") if p.is_file()])
        if not files:
            report.missing.append(f"Required asset: {pattern}")
        for path in sorted(files):
            report.assets[str(path.resolve())] = checksum(path)
    modules = ["fastapi", "uvicorn", "anthropic", "datasets"]
    if config.env_name == "webshop":
        modules += ["gym", "spacy", "en_core_web_lg", "pyserini", "bs4"]
    if config.env_name == "browsecomp-plus":
        modules += ["faiss", "fastmcp", "transformers", "torch", "tevatron"]
        if config.tools_config.get("searcher_type") == "bm25":
            modules += ["pyserini"]
        if config.tools_config.get("snippet_max_tokens", 512) > 0:
            cache = config.service_env.get("HF_HUB_CACHE", "")
            ref = Path(cache) / "models--Qwen--Qwen3-0.6B/refs/main"
            expected = config.tools_config.get("tokenizer_revision")
            if not ref.is_file() or ref.read_text().strip() != expected:
                report.missing.append("Search tokenizer refs/main must match the pinned tokenizer_revision")
            if any(config.service_env.get(key) != "1" for key in ("HF_HUB_OFFLINE", "TRANSFORMERS_OFFLINE")):
                report.missing.append("Search snippets require HF_HUB_OFFLINE=1 and TRANSFORMERS_OFFLINE=1")
    if config.python:
        script = (
            "import importlib.util,json; print(json.dumps([m for m in "
            + repr(modules)
            + " if importlib.util.find_spec(m) is None]))"
        )
        try:
            proc = subprocess.run(
                [config.python, "-c", script], check=True, capture_output=True, text=True, timeout=30
            )
            missing = json.loads(proc.stdout)
        except (OSError, ValueError, subprocess.SubprocessError):
            missing = ["configured worker Python is unavailable"]
    else:
        missing = [module for module in modules if importlib.util.find_spec(module) is None]
    report.missing.extend(f"Worker dependency: {module}" for module in missing)
    report.ready = not report.missing
    return report


def prepare_environment(cfg: ExperimentConfig, *, clone: bool = False) -> PreparationReport:
    spec = cfg.task.task_environment
    if spec is None or spec.type != "memoryarena":
        raise ValueError("--environment-config requires a registered MemoryArena runtime configuration")
    report = inspect_environment(ArenaRuntimeConfig.model_validate(spec.config), clone=clone)
    output = Path(cfg.output.dir)
    output.mkdir(parents=True, exist_ok=True)
    (output / "preparation.json").write_text(report.model_dump_json(indent=2), encoding="utf-8")
    return report
