"""Compare this bounded refactor with its archived parent checks."""

import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from collections import Counter
from pathlib import Path

CHECKS = Path(__file__).resolve().parent
ROOT = CHECKS.parents[1]
DOCS = ROOT / "docs/datasets/memoryarena"


def git(*args):
    return subprocess.check_output(["git", "-c", "core.safecrlf=false", *args], cwd=ROOT)


def tests(data):
    return {
        node.get("classname", "") + "::" + node.get("name", ""): (
            "failed" if node.find("failure") is not None or node.find("error") is not None
            else "skipped" if node.find("skipped") is not None else "passed"
        )
        for node in ET.fromstring(data).iter("testcase")
    }


def types(data):
    result = Counter()
    for line in data.decode("utf-8-sig").splitlines():
        match = re.match(r"(.+?):\d+(?::\d+)?: error: (.+)", line)
        if match:
            result[(match[1].replace("\\", "/"), match[2])] += 1
    return result


parent = "3426dddc07d4ac4eebebb5d4a4a210ffc3a62530"
with zipfile.ZipFile(DOCS / "layout-evidence.zip") as archive:
    previous = tests(archive.read("pytest-current.xml"))
    previous_types = types(archive.read("mypy-current.log"))
current = tests((CHECKS / "pytest-current.xml").read_bytes())
current_types = types((CHECKS / "mypy-current.log").read_bytes())
failed = {name for name, status in current.items() if status == "failed"}
previous_failed = {name for name, status in previous.items() if status == "failed"}
assert failed == previous_failed, sorted(failed - previous_failed)
assert current_types == previous_types, current_types - previous_types
related_prefixes = (
    "tests.benchmarks.memoryarena.", "tests.test_environment_extensions", "tests.test_control_completeness",
    "tests.test_experiment_controls", "tests.test_scoring_checkpoint",
)
related = {name: status for name, status in current.items() if name.startswith(related_prefixes)}
official = {name: status for name, status in current.items() if name.startswith("tests.benchmarks.memoryarena.test_official_parity")}
assert set(related.values()) == {"passed"} and len(official) == 33
assert set(official.values()) == {"passed"}
source_paths = git("ls-files", "src", "tests").decode().splitlines()
source_hashes = {path: hashlib.sha256((ROOT / path).read_bytes().replace(b"\r\n", b"\n")).hexdigest() for path in source_paths if path.endswith(".py")}
changed = git("diff", "--name-only", parent, "--", "src", "tests").decode().splitlines()
inputs = {path: source_hashes[path] for path in changed if path in source_hashes}
historical = git("ls-tree", "-r", "--name-only", parent, "--", "docs/datasets/memoryarena").decode().splitlines()
historical = [path for path in historical if path.endswith((".json", ".zip"))]
for path in historical:
    old, new = git("show", f"{parent}:{path}"), (ROOT / path).read_bytes()
    if path.endswith(".json"):
        old, new = old.replace(b"\r\n", b"\n"), new.replace(b"\r\n", b"\n")
    assert old == new, path

assert git("show", "37a0e19:src/dumemeval/datasets/benchmark.py") == (ROOT / "src/dumemeval/datasets/benchmark.py").read_bytes().replace(b"\r\n", b"\n")
for path in ("src/dumemeval/datasets/benchmark.py", "src/dumemeval/metrics/core/registry.py"):
    assert "_load_builtin_integrations" not in (ROOT / path).read_text(encoding="utf-8")
assert "_load_builtin_providers" not in (ROOT / "src/dumemeval/environments.py").read_text(encoding="utf-8")

report = {
    "parent_commit": parent,
    "upstream_commit": "37a0e1959e14509898fca856d8fd3fd2a720aefb",
    "source_and_tests_sha256": hashlib.sha256(json.dumps(source_hashes, sort_keys=True).encode()).hexdigest(),
    "changed_python_inputs_sha256": inputs,
    "current": dict(Counter(current.values())),
    "parent": dict(Counter(previous.values())),
    "related": dict(Counter(related.values())),
    "official_parity": dict(Counter(official.values())),
    "new_failed_test_identities": sorted(failed - previous_failed),
    "resolved_failed_test_identities": sorted(previous_failed - failed),
    "mypy": {"errors": sum(current_types.values()), "files": len({name[0] for name in current_types}), "same_diagnostics_as_parent": True},
    "dataset_registry_matches_upstream": True,
    "historical_json_and_zip_files_unchanged": len(historical),
    "historical_comparison": "ZIP bytes; JSON with Git LF normalization",
    "ruff": (CHECKS / "ruff.log").read_text().strip(),
    "format": (CHECKS / "format.log").read_text().strip(),
    "delivery": json.loads((CHECKS / "delivery.json").read_text()),
}
git("diff", "--check")
expected = DOCS / "framework-reuse-verification.json"
if expected.exists():
    assert report["source_and_tests_sha256"] == json.loads(expected.read_text(encoding="utf-8"))["source_and_tests_sha256"]
(CHECKS / "verification.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(json.dumps({key: value for key, value in report.items() if key != "changed_python_inputs_sha256"}, indent=2, ensure_ascii=False))
