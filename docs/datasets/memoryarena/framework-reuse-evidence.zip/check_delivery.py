"""Verify the built wheel outside the checkout without calling a model."""

import ast
import hashlib
import json
import os
import subprocess
import sys
import zipfile
from pathlib import Path

CHECKS = Path(__file__).resolve().parent
ROOT = CHECKS.parents[1]
wheel = next((CHECKS / "dist").glob("*.whl"))
wheel_hash = hashlib.sha256(wheel.read_bytes()).hexdigest()
installed = CHECKS / f"installed-{wheel_hash[:12]}"
installed.mkdir(exist_ok=True)
modules = 0
with zipfile.ZipFile(wheel) as package:
    for source in (ROOT / "src").rglob("*.py"):
        member = source.relative_to(ROOT / "src").as_posix()
        assert package.read(member).replace(b"\r\n", b"\n") == source.read_bytes().replace(b"\r\n", b"\n"), member
        modules += 1
    for member in package.namelist():
        assert (installed / member).resolve().is_relative_to(installed.resolve()), member
    package.extractall(installed)

tree = ast.parse((ROOT / "tests/benchmarks/memoryarena/test_layout.py").read_text(encoding="utf-8"))
scripts = {}
first_imports = []
for node in tree.body:
    if not isinstance(node, ast.FunctionDef):
        continue
    for statement in node.body:
        if isinstance(statement, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "script" for target in statement.targets):
            scripts[node.name] = ast.literal_eval(statement.value)
    for decorator in node.decorator_list:
        if isinstance(decorator, ast.Call) and ast.literal_eval(decorator.args[0]) == "first":
            first_imports = ast.literal_eval(decorator.args[1])

environment = {**os.environ, "PYTHONPATH": str(installed), "PYTHONUTF8": "1"}
guard = "import dumemeval; from pathlib import Path; assert Path(dumemeval.__file__).resolve().is_relative_to(Path.cwd()), dumemeval.__file__\n"


def run(script, *args):
    result = subprocess.run([sys.executable, "-c", guard + script, *args], cwd=installed, env=environment, capture_output=True, text=True, timeout=90)
    if result.returncode:
        raise RuntimeError(result.stdout + result.stderr)


for first in first_imports:
    run(scripts["test_direct_import_and_registries_without_optional_worker_sdks"], first)
run(scripts["test_registered_overrides_survive_registry_lookups"])
subprocess.run([sys.executable, str(installed / "dumemeval/task_environments/agent_tool.py"), "--help"], cwd=installed, env=environment, check=True, capture_output=True, text=True, timeout=30)

run("""
import os
import time
from dumemeval.benchmarks.memoryarena.environment.client import ArenaClient
from dumemeval.benchmarks.memoryarena.environment.config import ArenaConnection, ArenaRuntimeConfig
from dumemeval.benchmarks.memoryarena.environment.service import OfficialService
config = ArenaRuntimeConfig(reference=Path(os.environ['MEMORYARENA_REFERENCE']), env_name='math', service_env={'ANTHROPIC_API_KEY': 'fixture-never-called'})
service = OfficialService(config, Path('worker-proof'))
try:
    service.start()
    client = ArenaClient(ArenaConnection(base_url=service.url, env_name='math', env_config={'backend': 'anthropic', 'model_name': 'fixture-never-called'}))
    for attempt in range(100):
        try:
            client.available()
            break
        except RuntimeError:
            time.sleep(0.1)
    with client:
        assert client.reset(seed=17).observation['step'] == 0
        assert client.step({'type': 'final', 'answer': '2'}).observation['final'] == '2'
        assert client.tools()
finally:
    service.close()
assert service.process is None
""")

report = {
    "wheel": wheel.name,
    "sha256": wheel_hash,
    "source_modules_checked": modules,
    "isolated_import_and_override_checks": len(first_imports) + 1,
    "agent_client_help": "passed",
    "official_math_worker_lifecycle": "passed",
    "paid_model_calls": 0,
}
(CHECKS / "delivery.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report, indent=2))
