Submission validation on 2026-09-16. Logs are UTF-8 and known credentials are redacted.
The before log is the deterministic missing-SDK/prompt-policy reproduction; final logs record repaired tests.
The full suite and full mypy still fail inherited upstream checks. See baseline-comparison.json for identity-based comparison.
The upstream baseline source/tests/config were verified byte-for-byte against Git archive 37a0e1959e14509898fca856d8fd3fd2a720aefb.
Hermes image build and check-only/preparation made no model calls. Historical real model evidence is in memoryarena-hermes-evidence.zip.
