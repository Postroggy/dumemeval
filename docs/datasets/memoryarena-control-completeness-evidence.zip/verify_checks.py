"""Verify current checks against the committed 3f6dd63 and upstream baseline evidence."""

import argparse
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import zipfile
from collections import Counter
from pathlib import Path


def tests(data):
    return {
        node.attrib["classname"] + "::" + node.attrib["name"]: (
            "failed" if node.find("failure") is not None or node.find("error") is not None
            else "skipped" if node.find("skipped") is not None else "passed"
        )
        for node in ET.fromstring(data).iter("testcase")
    }


def diagnostics(data):
    output = Counter()
    for line in data.decode("utf-8-sig").splitlines():
        match = re.match(r"(.+?):\d+(?::\d+)?: error: (.+)", line)
        if match:
            output[(match[1].replace("\\", "/"), match[2])] += 1
    return output


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--repo", type=Path, default=Path.cwd())
parser.add_argument("--checks", type=Path, default=Path(__file__).resolve().parent)
args = parser.parse_args()
archive = args.repo / "docs/datasets/memoryarena-review-evidence.zip"
current = tests((args.checks / "pytest-current.xml").read_bytes())
current_errors = diagnostics((args.checks / "mypy-current.log").read_bytes())
with zipfile.ZipFile(archive) as bundle:
    previous = tests(bundle.read("checks/pytest-current.xml"))
    baseline = tests(bundle.read("baseline/pytest-baseline.xml"))
    previous_errors = diagnostics(bundle.read("checks/mypy-current.log"))
    baseline_errors = diagnostics(bundle.read("baseline/mypy-baseline.log"))
related = {name: status for name, status in current.items() if name.startswith((
    "tests.test_memoryarena_", "tests.test_experiment_controls", "tests.test_control_completeness",
))}
official = {name: status for name, status in current.items() if name.startswith("tests.test_memoryarena_official_parity")}
regressions = {name: status for name, status in current.items() if name.startswith("tests.test_control_completeness")}
report = {
    "previous_commit": "3f6dd636b67f16621b3259d4a439da538df968ce",
    "upstream_commit": "37a0e1959e14509898fca856d8fd3fd2a720aefb",
    "comparison_archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
    "current": dict(Counter(current.values())),
    "previous": dict(Counter(previous.values())),
    "upstream": dict(Counter(baseline.values())),
    "related": dict(Counter(related.values())),
    "official_parity": dict(Counter(official.values())),
    "new_regressions": regressions,
    "new_failures_from_previous": sorted(name for name, status in current.items() if status == "failed" and previous.get(name) != "failed"),
    "new_failures_from_upstream": sorted(name for name, status in current.items() if status == "failed" and baseline.get(name) != "failed"),
    "mypy": {
        "current": sum(current_errors.values()),
        "previous": sum(previous_errors.values()),
        "upstream": sum(baseline_errors.values()),
        "same_as_previous": current_errors == previous_errors,
        "new_diagnostics": [{"file": file, "message": message, "count": count}
            for (file, message), count in (current_errors - baseline_errors).items()],
    },
}
assert not report["new_failures_from_previous"] and not report["new_failures_from_upstream"]
assert current_errors == previous_errors and not report["mypy"]["new_diagnostics"]
assert set(related.values()) == {"passed"} and set(official.values()) == {"passed"}
assert len(regressions) == 10 and set(regressions.values()) == {"passed"}
(args.checks / "verification.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps({key: value for key, value in report.items() if key != "new_regressions"}, indent=2))
