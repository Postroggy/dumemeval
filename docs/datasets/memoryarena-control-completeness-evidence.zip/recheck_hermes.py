"""Recompare the committed historical Hermes artifacts without running an agent or judge."""

import argparse
import hashlib
import json
import zipfile
from pathlib import Path

from dumemeval.comparison import compare_runs, load_run
from dumemeval.comparison.report import write_comparison


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path.cwd())
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    archive = args.repo / "docs/datasets/memoryarena-hermes-evidence.zip"
    archive_hash = hashlib.sha256(archive.read_bytes()).hexdigest()
    report = {"archive_sha256": archive_hash, "model_calls": 0, "scenes": {}}
    with zipfile.ZipFile(archive) as bundle:
        archived_comparison = json.loads(bundle.read("math/comparison/comparison.json"))
        for scene in ["math", "diagnostic"]:
            sources = {}
            for arm in ["off", "on"]:
                directory = args.output / "inputs" / scene / arm
                directory.mkdir(parents=True, exist_ok=True)
                for name in ["summary.json", "experiment_config.json"]:
                    member = f"{scene}/{arm}/{name}"
                    data = bundle.read(member)
                    sources[member] = hashlib.sha256(data).hexdigest()
                    (directory / name).write_bytes(data)
            runs = [load_run(args.output / "inputs" / scene / arm) for arm in ["off", "on"]]
            comparison = compare_runs(runs, baseline="off")
            for arm in ["off", "on"]:
                assert any(
                    f"{arm}:" in warning and "agent_skills" in warning and "observed_prompts" in warning
                    and "unverified" in warning for warning in comparison.warnings
                )
            write_comparison(comparison, runs, args.output / scene)
            current_deltas = [delta.model_dump(mode="json") for delta in comparison.deltas]
            unchanged = None
            if scene == "math":
                unchanged = current_deltas == archived_comparison["deltas"]
                assert unchanged, "Historical numeric comparisons must not change"
            report["scenes"][scene] = {
                "input_hashes": sources,
                "warnings": comparison.warnings,
                "deltas": current_deltas,
                "matches_archived_math_deltas": unchanged,
            }
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == archive_hash
    report["archived_math_warnings"] = archived_comparison["warnings"]
    report["historical_archive_unchanged"] = True
    (args.output / "verification.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({scene: value["warnings"] for scene, value in report["scenes"].items()}, indent=2))


if __name__ == "__main__":
    main()
