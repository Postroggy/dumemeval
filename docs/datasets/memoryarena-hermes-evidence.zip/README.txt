Hermes historical functional acceptance evidence

math/: 86 original records from hermes-controlled-20260916, plus original hash manifest and 4 actual prompts.
diagnostic/: 74 original records from hermes-memory-link-20260916, plus original hash manifest and 4 actual prompts.
failed-provider-auto/: selected failed 401 attempt, 0/2 sessions and unmeasured official score.

All original evidence bytes and hashes are preserved. Read math/validation.json and diagnostic/diagnosis.json first.
Historical scripts and reports refer to their original Windows paths and submission status; they are records of that run.
Use docs/datasets/memoryarena-hermes.md and configs/memoryarena/hermes_repro.py for current portable instructions.
Historical model runs used DuMemEval 909e185; current source fixes are covered by separate regression checks.
Hermes automatic read/token/cost counters in the framework are incomplete; native tool evidence proves memory reads, native token counters are preserved, costs are unknown.
The marker diagnostic is NOT an official MemoryArena score or a statistical performance evaluation.
