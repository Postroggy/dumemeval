"""Verify the pinned Hermes provider path without emitting credentials."""
import json
import os
from pathlib import Path
import subprocess
import yaml

from harbor.agents.installed.hermes import Hermes
from run_arm import HERE, IMAGE

proxy = yaml.safe_load(Path("C:/Users/32144/AppData/Local/DuMemEval/cliproxyapi-7.3.2/config.yaml").read_text(encoding="utf-8"))
key = proxy["api-keys"][0]
env = os.environ.copy()
env.update(OPENAI_API_KEY=key, OPENAI_BASE_URL="http://host.docker.internal:8317/v1")
config = Hermes._build_config_yaml("gpt-5.5(medium)")
code = '''
import hashlib, json, os, pathlib, subprocess
pathlib.Path('/tmp/hermes/config.yaml').write_text(CONFIG, encoding='utf-8')
from hermes_cli.runtime_provider import resolve_runtime_provider
r = resolve_runtime_provider(requested='openai-api', target_model='gpt-5.5(medium)')
d = {k: r.get(k) for k in ['provider', 'api_mode', 'base_url', 'source']}
d['correct_key'] = r.get('api_key') == os.environ['OPENAI_API_KEY']
skill = pathlib.Path('/tmp/hermes/skills/persistent-memory/SKILL.md')
d['skill_sha256'] = hashlib.sha256(skill.read_bytes()).hexdigest()
print(json.dumps({'provider_probe': d}), flush=True)
assert d['base_url'] == 'http://host.docker.internal:8317/v1', d
assert d['correct_key']
assert d['api_mode'] in {'chat_completions', 'codex_responses'}, d
p = subprocess.run(['hermes', '--yolo', 'chat', '-q', 'Reply with OK. Do not use tools.', '-Q', '--model', 'gpt-5.5(medium)', '--provider', 'openai-api'], text=True, capture_output=True, timeout=120)
print(json.dumps({'exit_code': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}), flush=True)
assert p.returncode == 0
assert 'OK' in p.stdout
'''.replace('CONFIG', repr(config))
p = subprocess.run(['docker', 'run', '--rm', '-i', '-e', 'OPENAI_API_KEY', '-e', 'OPENAI_BASE_URL', IMAGE, 'python', '-'], input=code, text=True, capture_output=True, env=env, timeout=180)
out = (p.stdout + p.stderr).replace(key, '[REDACTED]')
(HERE / 'hermes-provider-probe.log').write_text(out, encoding='utf-8')
print(out)
assert p.returncode == 0, f'Native Hermes provider probe exited {p.returncode}'
