"""Audit real Hermes artifacts; never run or replay benchmark/model actions."""
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import yaml

from dumemeval.artifacts.redaction import Redactor
from run_arm import ROOT, HERE, IMAGE, HERMES_COMMIT

RUN = 'hermes-controlled-20260916'
R = ROOT / 'results/memoryarena' / RUN

def read(p):
    return json.loads(p.read_text(encoding='utf-8'))

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def rel(p):
    return p.relative_to(R).as_posix()

def native_calls(session):
    messages = session['messages']
    observations = {m['tool_call_id']: m['content'] for m in messages if m.get('role') == 'tool'}
    calls = []
    for m in messages:
        for c in m.get('tool_calls') or []:
            f = c['function']
            args = json.loads(f['arguments']) if isinstance(f['arguments'], str) else f['arguments']
            content = observations.get(c['id'])
            assert content is not None, c['id']
            result = json.loads(content) if isinstance(content, str) else content
            calls.append({'id': c['id'], 'name': f['name'], 'arguments': args, 'result': result})
    return calls

proxy = yaml.safe_load(Path('C:/Users/32144/AppData/Local/DuMemEval/cliproxyapi-7.3.2/config.yaml').read_text(encoding='utf-8'))
redactor = Redactor({**os.environ, 'DUMEMEVAL_PROXY_KEY': proxy['api-keys'][0]})
redactor.tree(R)
for name in ['on-v2-console.log', 'off-v2-console.log', 'hermes-provider-probe.log', 'image-build-v2.log']:
    source = HERE / name
    (R / 'inputs' / name).write_text(redactor.text(source.read_text(encoding='utf-8')), encoding='utf-8')
for source, target in [(HERE/'image/Dockerfile', 'Dockerfile'),
                       (ROOT/'configs/memoryarena/skills/persistent-memory/SKILL.md', 'persistent-memory-SKILL.md'),
                       (HERE/'probe_hermes.py', 'probe_hermes.py'),
                       (Path(__file__), 'audit_run.py')]:
    shutil.copyfile(source, R/'inputs'/target)

summaries = {a: read(R/a/'summary.json') for a in ['on', 'off']}
assert summaries['on']['provenance']['controls'] == summaries['off']['provenance']['controls']
manifest = read(R/'inputs/runtime-manifest.json')
image = json.loads(subprocess.check_output(['docker','image','inspect',IMAGE], text=True))[0]
assert image['Id'] == manifest['docker_image_id']
assert image['Config']['Labels']['org.opencontainers.image.revision'] == HERMES_COMMIT
for name, field in [('run_arm.py','launcher_sha256'), ('controlled-math.yaml','config_sha256')]:
    assert sha(R/'inputs'/name) == manifest[field]

report = {'run': RUN, 'runtime_manifest': manifest, 'arms': {}, 'prompt_checks': [],
          'control_fingerprints_equal': True, 'control_fingerprint_count': len(summaries['on']['provenance']['controls']),
          'limitations': [
              'One complete two-round Math sample only; this is not a full-dataset performance estimate.',
              'Cross-runtime prompts and wire API protocols differ; on/off controls are compared within Hermes.',
              'DirectoryAdapter automatic retrieval detection only supports Claude Read. Hermes reads below are independently verified against native read_file results and saved snapshots.',
              'Harbor 0.22 Hermes ATIF conversion misses session-level usage. Its zero token/cost metrics are not measured zero consumption. Native usage counters are retained separately; cost remains unknown.',
              'A local launcher patches the preinstalled-version check and native provider routing; these compatibility changes have not been committed to the repository.'
          ]}
native_ids, system_hashes, calls_by_session = [], [], {}
for arm, summary in summaries.items():
    assert summary['mock'] is False
    task = summary['per_task'][0]
    assert task['n_sessions'] == task['n_success'] == 2 and task['execution_status'] == 'completed'
    rounds = [d for d in summary['benchmark']['details'] if 'round_idx' in d]
    assert len(rounds) == 2 and all(d['score_status'] == 'measured' for d in rounds)
    cp = read(R/arm/'checkpoints/memoryarena_math_39.json')
    env_trace_path = next((R/arm/'environments').glob('*/trace.json'))
    trace, runtime = read(env_trace_path), read(env_trace_path.with_name('runtime.json'))
    assert trace['closed'] and runtime['closed'] and runtime['cleanup_status'] == 'completed'
    assert all(e['status'] == 'completed' for e in trace['lifecycle'])
    assert sum(e['operation'] == 'reset' for e in trace['lifecycle']) == 1
    evidence = [e for e in trace['evidence'] if e.get('action_id')]
    assert len(evidence) == len({e['action_id'] for e in evidence}) == 4
    assert Counter(e['tool'] for e in evidence) == {'reasoning': 2, 'submit': 2}
    with socket.socket() as sock:
        sock.settimeout(1)
        assert sock.connect_ex(('127.0.0.1', runtime['port'])) != 0
    sessions = []
    for sid in [1, 2]:
        p = R/arm/'trials'/f'dumemeval_memoryarena_math_39__session_{sid}'
        exported = [json.loads(line) for line in (p/'agent/hermes-session.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
        assert len(exported) == 1
        native = exported[0]
        native_ids.append(native['id'])
        system_hashes.append(native['system_prompt_hash'])
        assert native['parent_session_id'] is None
        assert native['model'] == 'gpt-5.5(medium)'
        assert native['billing_provider'] == 'openai-api'
        assert native['billing_base_url'] == 'http://host.docker.internal:8317/v1'
        calls = native_calls(native)
        calls_by_session[(arm,sid)] = calls
        assert any(c['name']=='skill_view' and c['arguments'].get('name')=='persistent-memory' and c['result']['success'] for c in calls)
        assert all(c['result'].get('exit_code',0)==0 and not c['result'].get('error') for c in calls)
        atif = read(p/'agent/trajectory.json')
        assert sum(len(s.get('tool_calls') or []) for s in atif['steps']) == len(calls)
        env = read(p/'config.json')['environment']
        memory_mount = any(m.get('target')=='/app/memory' for m in env.get('mounts',[]))
        assert memory_mount == (arm == 'on')
        assert ('DUMEMEVAL_MEMORY_DIR' in env.get('env',{})) == (arm == 'on')
        logs = (p/'trial.log').read_text(encoding='utf-8')
        assert 'memory_enabled: false' in logs and 'user_profile_enabled: false' in logs
        sessions.append({
            'session': sid, 'native_id': native['id'], 'native_parent': native['parent_session_id'],
            'system_prompt_sha256': native['system_prompt_hash'], 'memory_mount': memory_mount,
            'native_trajectory': rel(p/'agent/hermes-session.jsonl'), 'atif_trajectory': rel(p/'agent/trajectory.json'),
            'tool_counts': dict(Counter(c['name'] for c in calls)),
            'native_usage': {k:native.get(k) for k in ['input_tokens','output_tokens','cache_read_tokens','cache_write_tokens','reasoning_tokens','api_call_count','estimated_cost_usd','actual_cost_usd','cost_status']}
        })
    report['arms'][arm] = {'completed_sessions': 2, 'official_metrics': summary['benchmark']['values'],
                           'round_scores': [d['official_score'] for d in rounds], 'sessions':sessions,
                           'framework_memory_ops':dict(Counter(op['op'] for op in cp['memory_ops'])),
                           'official_actions':[{k:e.get(k) for k in ['session_id','action_id','tool','status']} for e in evidence],
                           'environment_closed':True, 'service_port_closed':True,
                           'environment_revision':runtime['revision'], 'seed':runtime['seed']}
    if arm == 'off':
        assert not cp['memory_ops']
        assert not any(c['arguments'].get('path','').startswith('/app/memory') for sid in [1,2] for c in calls_by_session[(arm,sid)])

assert len(set(native_ids)) == 4
assert len(set(system_hashes)) == 1
report['four_distinct_native_sessions'] = True
report['native_system_prompts_equal'] = True
for sid in [1,2]:
    paths = [ROOT/'tasks_generated/memoryarena'/RUN/arm/f'memoryarena_math_39__session_{sid}/instruction.md' for arm in ['on','off']]
    assert paths[0].read_bytes() == paths[1].read_bytes()
    report['prompt_checks'].append({'session':sid, 'equal':True, 'sha256':sha(paths[0])})

snap = R/'on/snapshots/memoryarena-hermes-on/memoryarena_math_39'
first = snap/'session_1/cinfty_localization.md'
last = snap/'session_2/cinfty_localization.md'
write1 = next(c for c in calls_by_session[('on',1)] if c['name']=='write_file')
read2 = next(c for c in calls_by_session[('on',2)] if c['name']=='read_file')
write2 = next(c for c in calls_by_session[('on',2)] if c['name']=='write_file')
assert write1['arguments']['content'].encode('utf-8') == first.read_bytes()
assert write2['arguments']['content'].encode('utf-8') == last.read_bytes()
assert read2['result']['truncated'] is False and read2['result']['file_size'] == first.stat().st_size
read_text = re.sub(r'^\d+\|','',read2['result']['content'],flags=re.M)
assert read_text.rstrip('\n') == first.read_text(encoding='utf-8').rstrip('\n')
assert sha(first) != sha(last)
report['cross_session_memory'] = {'first_write_call':write1['id'], 'second_read_call':read2['id'], 'second_write_call':write2['id'],
                                  'first_snapshot_sha256':sha(first), 'second_snapshot_sha256':sha(last),
                                  'read_matches_first_snapshot':True, 'read_before_reasoning':True}
on2 = calls_by_session[('on',2)]
assert on2.index(read2) < next(i for i,c in enumerate(on2) if 'arena_tool.py reasoning' in c['arguments'].get('command',''))
report['official_passrate_delta'] = summaries['on']['benchmark']['values']['overall_average_passrate'] - summaries['off']['benchmark']['values']['overall_average_passrate']
old = ROOT/'results/memoryarena/hermes-controlled-20260915/on/summary.json'
failed = read(old)
assert failed['per_task'][0]['n_success'] == 0 and not failed['benchmark']['values']
report['prior_failed_attempt'] = {'path':str(old), 'reason':'HTTP 401 during initial provider=auto runtime setup', 'completed_sessions':0, 'scoring':'unmeasured', 'retained':True}
report['tracked_worktree_changes'] = subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True).strip()
report['remaining_benchmark_containers'] = [n for n in subprocess.check_output(['docker','ps','--format','{{.Names}}'],text=True).splitlines() if n.startswith('dumemeval_memoryarena_math_39__')]
assert not report['tracked_worktree_changes'] and not report['remaining_benchmark_containers']
report['known_secret_scan'] = 'passed'
(R/'validation.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
rows = '\n'.join(f"| Hermes 0.21.3 × {'directory 记忆' if arm=='on' else 'none 无记忆'} × CLIProxyAPI → GPT-5.5（medium） | {a['completed_sessions']}/2 | {a['official_metrics']['overall_average_passrate']} |" for arm,a in report['arms'].items())
md = f'''# Hermes 真实复跑验收

同一条完整的两轮 Math 样本（row 39），两组均为实际 Harbor + Hermes + 模型 API 运行，mock=false。

| 组合 | 完成会话 | 官方 paper passrate |
| --- | ---: | ---: |
{rows}

记忆组减去无记忆组的官方得分差为 **{report['official_passrate_delta']}**。本次证明了这个样本的运行和跨会话记忆链路，不能推出记忆具有统计上的性能增益。

## 核验结果

- 4 个不同的 Hermes 原生会话 ID，均无父会话；原生 system prompt 一致。
- 两轮实际任务 instruction.md 在 on/off 间逐字一致；{report['control_fingerprint_count']} 项控制指纹一致；模型、镜像、数据、seed=37 均固定。
- 两组都各有 2 次官方 reasoning、2 次 submit；官方评分均为 measured。环境仅初始化/重置一次后连续执行两轮，收尾关闭服务与会话容器。
- directory 组第一会话写入笔记，第二会话 read_file 的完整内容与第一份快照匹配，并在官方 reasoning 前读取，然后更新；none 组无记忆挂载、无框架记忆操作。
- Hermes 原生 memory 与 user profile 在两组均关闭。共享的 persistent-memory 技能文件未改动。

## 接口与兼容处理

Hermes 0.21.3（官方提交 `{HERMES_COMMIT}`）通过 `--provider openai-api` 使用 Responses 接口，连接本地 CLIProxyAPI 7.3.2；模型参数是 `gpt-5.5(medium)`。官方 Math 环境的 reasoning/judge 也使用同一模型与代理。

Harbor 0.22.0 的旧安装检查使用了无效的 `hermes version`，默认 OpenAI provider 路由又未显式选择 provider。本地复跑入口改为验证预装版本、使用 `--version` 并指定 provider；Hermes.run 和会话导出函数保持原样。技能直接放进容器原生目录以避免 Windows 路径转换。具体入口、配置、Dockerfile 和版本清单见 [inputs](inputs)。这些兼容处理尚未提交到仓库。

第一次 provider=auto 尝试因 HTTP 401 失败，0/2 完成，官方评分未测量。原始失败目录 `hermes-controlled-20260915` 保留；当前成功复跑使用独立目录。

## 统计边界

- 当前自动记忆读取统计只支持 Claude 的 Read；Hermes 的读取由原生 read_file 日志和快照独立核对。
- Harbor 的 Hermes ATIF 转换没有导入原生会话级 token 统计，所以汇总中的 token/cost=0 不能解释为零消耗。真实原生用量计数保存在 [validation.json](validation.json)，成本未知。
- 这是单样本复跑；不同 runtime 的系统提示词与接口协议有差异，不能据此作严格的跨 runtime 性能排名。

## 证据

- [完整核验 JSON](validation.json)
- [记忆组原始汇总](on/summary.json) / [无记忆组原始汇总](off/summary.json)
- [框架对照报告](comparison/comparison.md)（token/cost 和自动读取统计须按上述边界解释）
- [运行版本清单](inputs/runtime-manifest.json)
- [第一会话记忆](on/snapshots/memoryarena-hermes-on/memoryarena_math_39/session_1/cinfty_localization.md)
- [第二会话原生轨迹](on/trials/dumemeval_memoryarena_math_39__session_2/agent/hermes-session.jsonl)

运行材料通过已知密钥明文扫描；源码工作区无改动。`evidence-sha256.json` 记录本目录证据文件哈希。
'''
(R/'validation.md').write_text(md,encoding='utf-8')
redactor.tree(R)
for p in R.rglob('*'):
    if not p.is_file(): continue
    data = p.read_bytes()
    assert not any(s.encode('utf-8') in data for s in redactor.secrets), rel(p)
    if p.suffix=='.json': read(p)
    if p.suffix=='.jsonl':
        for line in data.decode('utf-8').splitlines():
            if line.strip(): json.loads(line)
hashes = {rel(p):sha(p) for p in sorted(R.rglob('*')) if p.is_file() and p.name!='evidence-sha256.json'}
(R/'evidence-sha256.json').write_text(json.dumps(hashes,indent=2),encoding='utf-8')
print(json.dumps({'passed':True,'arms':{a:v['official_metrics'] for a,v in report['arms'].items()},'delta':report['official_passrate_delta'],'artifacts_hashed':len(hashes),'report':str(R/'validation.md')},ensure_ascii=False))
