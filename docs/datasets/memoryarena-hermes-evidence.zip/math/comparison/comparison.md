# DuMemEval 对比（vs baseline）

> off=results\memoryarena\hermes-controlled-20260916\off · on=results\memoryarena\hermes-controlled-20260916\on

## Runs

| run | tasks | benchmark | judge | git |
|---|---|---|---|---|
| off（baseline） | 1 | memoryarena_math | gpt-5.5(medium)×1 | `909e185` |
| on | 1 | memoryarena_math | gpt-5.5(medium)×1 | `909e185` |

## Metrics

| metric | off | on | Δ vs baseline |
|---|---|---|---|
| `efficiency.cost_usd` | 0.0000 | 0.0000 | on: +0.0000 ↓ |
| `efficiency.tokens_in` | 0.0000 | 0.0000 | on: +0.0000 ↓ |
| `efficiency.tokens_out` | 0.0000 | 0.0000 | on: +0.0000 ↓ |
| `memoryarena_math.avg_progress_score` | 1.0000 | 1.0000 | on: +0.0000 ↓ |
| `memoryarena_math.is_correct` | 1.0000 | 1.0000 | on: +0.0000 ↓ |
| `memoryarena_math.overall_average_passrate` | 1.0000 | 1.0000 | on: +0.0000 ↓ |
| `trace.empty_output_rate` | 0.0000 | 0.0000 | on: +0.0000 ↓ |
| `trace.error_rate` | 0.0000 | 0.0000 | on: +0.0000 ↓ |
| `trace.memory_observation_coverage` | 0.0000 | 1.0000 | on: +1.0000 ↑ |
| `trace.memory_tool_used_rate` | - | 1.0000 | on: - |
| `trace.trace_captured_rate` | 1.0000 | 1.0000 | on: +0.0000 ↓ |
| `utility.success_rate` | 1.0000 | 1.0000 | on: +0.0000 ↓ |
| `utility.turns` | 2.0000 | 2.0000 | on: +0.0000 ↓ |
