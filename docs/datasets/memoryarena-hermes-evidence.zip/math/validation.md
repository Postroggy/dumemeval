# Hermes 真实复跑验收

同一条完整的两轮 Math 样本（row 39），两组均为实际 Harbor + Hermes + 模型 API 运行，mock=false。

| 组合 | 完成会话 | 官方 paper passrate |
| --- | ---: | ---: |
| Hermes 0.21.3 × directory 记忆 × CLIProxyAPI → GPT-5.5（medium） | 2/2 | 1.0 |
| Hermes 0.21.3 × none 无记忆 × CLIProxyAPI → GPT-5.5（medium） | 2/2 | 1.0 |

记忆组减去无记忆组的官方得分差为 **0.0**。本次证明了这个样本的运行和跨会话记忆链路，不能推出记忆具有统计上的性能增益。

## 核验结果

- 4 个不同的 Hermes 原生会话 ID，均无父会话；原生 system prompt 一致。
- 两轮实际任务 instruction.md 在 on/off 间逐字一致；9 项控制指纹一致；模型、镜像、数据、seed=37 均固定。
- 两组都各有 2 次官方 reasoning、2 次 submit；官方评分均为 measured。环境仅初始化/重置一次后连续执行两轮，收尾关闭服务与会话容器。
- directory 组第一会话写入笔记，第二会话 read_file 的完整内容与第一份快照匹配，并在官方 reasoning 前读取，然后更新；none 组无记忆挂载、无框架记忆操作。
- Hermes 原生 memory 与 user profile 在两组均关闭。共享的 persistent-memory 技能文件未改动。

## 接口与兼容处理

Hermes 0.21.3（官方提交 `345cd2b057a452236de401d3534b8502a7465e8d`）通过 `--provider openai-api` 使用 Responses 接口，连接本地 CLIProxyAPI 7.3.2；模型参数是 `gpt-5.5(medium)`。官方 Math 环境的 reasoning/judge 也使用同一模型与代理。

Harbor 0.22.0 的旧安装检查使用了无效的 `hermes version`，默认 OpenAI provider 路由又未显式选择 provider。本地复跑入口改为验证预装版本、使用 `--version` 并指定 provider；Hermes.run 和会话导出函数保持原样。技能直接放进容器原生目录以避免 Windows 路径转换。具体入口、配置、Dockerfile 和版本清单见 [inputs](inputs)。这些兼容处理尚未提交到仓库。

第一次 provider=auto 尝试因 HTTP 401 失败，0/2 完成，官方评分未测量。原始失败目录 `hermes-controlled-20260915` 保留；当前成功复跑使用独立目录。

## 统计边界

- 当前自动记忆读取统计只支持 Claude 的 Read；Hermes 的读取由原生 read_file 日志和快照独立核对。
- Harbor 的 Hermes ATIF 转换没有导入原生会话级 token 统计，所以汇总中的 token/cost=0 不能解释为零消耗。真实原生用量计数保存在 [validation.json](validation.json)，成本未知。
- 这是单样本复跑；不同 runtime 的系统提示词与接口协议有差异，不能据此作严格的跨 runtime 性能排名。

## 证据

- [完整核验 JSON](validation.json)
- [记忆组原始汇总](on/summary.json) / [无记忆组原始汇总](off/summary.json)
- [框架对照报告](comparison/comparison.md)（token/cost 和自动读取统计须按上述边界解释）
- [运行版本清单](inputs/runtime-manifest.json)
- [第一会话记忆](on/snapshots/memoryarena-hermes-on/memoryarena_math_39/session_1/cinfty_localization.md)
- [第二会话原生轨迹](on/trials/dumemeval_memoryarena_math_39__session_2/agent/hermes-session.jsonl)

运行材料通过已知密钥明文扫描；源码工作区无改动。`evidence-sha256.json` 记录本目录证据文件哈希。
