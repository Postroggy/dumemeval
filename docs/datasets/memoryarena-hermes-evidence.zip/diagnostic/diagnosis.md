# 分数相同之后的复核

## 结论

Hermes 的跨会话目录记忆通道已实际工作。原来的单条 Math 样本在 GPT-5.5（medium）上两组都能答对，不能用其零分差证明记忆有益，也不能据此判断记忆没有运行。

## 原始 Math 运行存在真实行为差异

| 原生轨迹证据 | directory | none |
| --- | ---: | ---: |
| 完成会话 | 2/2 | 2/2 |
| 记忆文件写入/更新调用 | 2 | 0 |
| 记忆 read_file 调用 | 1 | 0 |
| 全部原生工具调用 | 12 | 7 |
| 官方 paper passrate | 1.0 | 1.0 |

原始 86 份证据的哈希再次核验通过。第二会话的读取内容与第一份记忆快照一致，none 组没有记忆挂载。官方 reasoning 与 submit 都有真实返回；两个会话均由官方 judge 判为 yes。

## 为什么这条 Math 样本分数相同

第二轮题面本身包含 Construction 3.14（仿射 C∞ 概形与结构层的构造）以及 Lemma 3.17（相关理想是 Poisson 理想）。无记忆组使用当前题面与官方 reasoning 工具就答对了。

第一会话保存的笔记主要是局部化的泛性质和唯一映射；有记忆组虽读取了该笔记，第二轮发给 reasoning 的请求没有显式加入这份笔记的独有内容。因此本样本在这次模型配置下没有表现出记忆收益，不能支持“记忆普遍无用”的结论。

对无记忆组的潜在隐式传递也作了检查：官方 MathEnvironment.reasoning 每次只构造 system + 当前 task 两条消息，没有向模型传入环境的 history。题面按数据集原文 backgrounds + questions 构造，参考 answers 在宿主提交评分时提供。

- [无记忆组第二轮题面](E:/dumemeval/tasks_generated/memoryarena/hermes-controlled-20260916/off/memoryarena_math_39__session_2/instruction.md:20)
- [第一轮记忆笔记](E:/dumemeval/results/memoryarena/hermes-controlled-20260916/on/snapshots/memoryarena-hermes-on/memoryarena_math_39/session_1/cinfty_localization.md)
- [官方 reasoning 实现](E:/dumemeval/.cache/memoryarena-repro/reference/env/env_systems/math_env.py:96)

## 新增：必须依靠记忆的真实隔离诊断

在宿主随机生成一个 128-bit 标记，只在第一会话提供。第二会话使用新的容器与原生会话；提示词和生成的任务文件里都没有该标记。沿用原先的 Hermes 0.21.3、Harbor 0.22.0、DirectoryAdapter 和 GPT-5.5（medium）接口配置，两组提示词逐字相同。

| 组别 | 第二会话真实输出 | 精确找回标记 |
| --- | --- | ---: |
| directory 记忆 | `3fb1f69824df7842e984b1617298c879` | 1/1 |
| none 无记忆 | `UNKNOWN` | 0/1 |

有记忆组第一会话通过工具将标记保存到 `memoryarena_parcels.json`；第二会话 read_file 返回的全文与第一份快照一致，最终准确输出标记。无记忆组正确地按约定输出 UNKNOWN。两组运行均完成；本诊断的回忆成绩由宿主严格字符串比较产生。

这个诊断验证了传递与检索通道，属于自行设计的功能检查，不是官方 MemoryArena 样本，也不是正式性能收益数据。

## 新增：评分器正反例

直接调用同一官方 MathEnvironment.judge 与实际模型接口：

- 正确参考答案 → yes / accepted=true。
- 明显错误答案（“Spec(A) 是恰好有七个元素的有限群”）→ no / accepted=false。

这次正反例排除了评分器在这两次请求中固定返回满分的情况，不能据此概括其全部判分准确率。

## 证据与限制

- [完整诊断 JSON](E:/dumemeval/results/diagnostics/hermes-memory-link-20260916/diagnosis.json)
- [随机标记记忆组](E:/dumemeval/results/diagnostics/hermes-memory-link-20260916/on/exact-recall.json)
- [随机标记无记忆组](E:/dumemeval/results/diagnostics/hermes-memory-link-20260916/off/exact-recall.json)
- [真实评分器正反例](E:/dumemeval/results/diagnostics/hermes-memory-link-20260916/judge-controls.json)

原有自动 read/token/cost 统计限制仍存在，已在先前验收报告说明；本次以原生轨迹和精确标记匹配核验。源码工作区没有改动，本地运行兼容处理与之前相同。原始验收证据保留，新诊断单独存放。
