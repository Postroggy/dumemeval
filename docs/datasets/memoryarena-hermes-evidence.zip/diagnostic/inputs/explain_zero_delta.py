"""Verify original evidence and report the independent memory/scorer controls."""
from __future__ import annotations

from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

import yaml
from dumemeval.artifacts.redaction import Redactor
from run_arm import ROOT, HERE, IMAGE


def read(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    original = ROOT / "results/memoryarena/hermes-controlled-20260916"
    root = ROOT / "results/diagnostics/hermes-memory-link-20260916"
    hashes = read(original/"evidence-sha256.json")
    assert all(sha(original/p)==value for p,value in hashes.items())
    marker = read(root/"inputs/marker.json")["marker"]
    proxy = yaml.safe_load(Path("C:/Users/32144/AppData/Local/DuMemEval/cliproxyapi-7.3.2/config.yaml").read_text(encoding="utf-8"))
    redactor = Redactor({**os.environ,"DUMEMEVAL_PROXY_KEY":proxy["api-keys"][0]})
    redactor.tree(root)
    controls = read(root/"judge-controls.json")
    assert controls["correct_accepted_wrong_rejected"]
    diagnosis = {"original_evidence_intact":True,"original_artifacts_verified":len(hashes),
                 "original_math_arms":{},"marker_controls":{},"judge_controls":controls,
                 "scope":"Real Hermes/Harbor/DirectoryAdapter diagnostic. Random-marker recall is not an official MemoryArena benchmark score."}
    native_ids, system_prompts = [], []
    for arm in ["on","off"]:
        old_summary=read(original/arm/"summary.json")
        old_calls=[]
        for path in (original/arm/"trials").glob("*/agent/hermes-session.jsonl"):
            session=json.loads(path.read_text(encoding="utf-8").splitlines()[0])
            old_calls.extend(call["function"] for m in session["messages"] for call in m.get("tool_calls") or [])
        old_counts=Counter(c["name"] for c in old_calls)
        diagnosis["original_math_arms"][arm]={"official_score":old_summary["benchmark"]["values"]["overall_average_passrate"],
             "native_tool_calls":len(old_calls),"memory_read_file_calls":old_counts.get("read_file",0),
             "memory_write_file_calls":old_counts.get("write_file",0)}
        summary=read(root/arm/"summary.json")
        assert summary["mock"] is False and summary["per_task"][0]["n_success"]==2
        answer=read(root/arm/"exact-recall.json")
        assert answer["matches_expected_control"]
        assert answer["exact_recall"] == (arm=="on")
        cp=read(root/arm/"checkpoints/memory_link_diagnostic.json")
        assert len(cp["sessions"])==2 and all(s["success"] for s in cp["sessions"])
        if arm=="off": assert not cp["memory_ops"]
        sessions=[]
        for sid in [1,2]:
            path=root/arm/"trials"/f"dumemeval_memory_link_diagnostic__session_{sid}"
            session=json.loads((path/"agent/hermes-session.jsonl").read_text(encoding="utf-8").splitlines()[0])
            native_ids.append(session["id"])
            system_prompts.append(session["system_prompt_hash"])
            assert session["parent_session_id"] is None
            assert session["billing_provider"]=="openai-api" and session["model"]=="gpt-5.5(medium)"
            assert session["billing_base_url"]=="http://host.docker.internal:8317/v1"
            env=read(path/"config.json")["environment"]
            memory_mount=any(m.get("target")=="/app/memory" for m in env.get("mounts",[]))
            assert memory_mount==(arm=="on")
            assert ("DUMEMEVAL_MEMORY_DIR" in env["env"])==(arm=="on")
            log=(path/"trial.log").read_text(encoding="utf-8")
            assert "memory_enabled: false" in log and "user_profile_enabled: false" in log
            calls=[c for m in session["messages"] for c in m.get("tool_calls") or []]
            results={m["tool_call_id"]:json.loads(m["content"]) for m in session["messages"] if m.get("role")=="tool"}
            for result in results.values():
                assert not result.get("error") and result.get("exit_code",0)==0
            assert any(c["function"]["name"]=="skill_view" for c in calls)
            if sid==2:
                assert marker not in session["system_prompt"]
                assert all(marker not in str(m.get("content","")) for m in session["messages"] if m.get("role")=="user")
                generated=ROOT/"tasks_generated/diagnostics/hermes-memory-link-20260916"/arm/"memory_link_diagnostic__session_2"
                assert all(marker.encode() not in p.read_bytes() for p in generated.rglob("*") if p.is_file())
                if arm=="on":
                    call=next(c for c in calls if c["function"]["name"]=="read_file")
                    result=results[call["id"]]
                    assert result["truncated"] is False
                    text=re.sub(r"^\d+\|","",result["content"],flags=re.M)
                    snapshot=root/"on/snapshots/marker-on/memory_link_diagnostic/session_1/memoryarena_parcels.json"
                    assert text.rstrip("\n")==snapshot.read_text(encoding="utf-8").rstrip("\n")
                    assert read(snapshot)["CobaltParcel"]==marker
                    answer["native_read_call_id"]=call["id"]
                    answer["read_matches_first_snapshot"]=True
                    answer["first_snapshot_sha256"]=sha(snapshot)
                else:
                    assert not any(c["function"]["name"] in ["read_file","write_file"] for c in calls)
                    assert marker not in json.dumps(session["messages"])
            sessions.append({"session":sid,"native_id":session["id"],"memory_mount":memory_mount,
                             "native_tool_names":[c["function"]["name"] for c in calls],
                             "trajectory":str(path/"agent/hermes-session.jsonl")})
        answer["sessions"]=sessions
        diagnosis["marker_controls"][arm]=answer
    assert len(set(native_ids))==4 and len(set(system_prompts))==1
    diagnosis["fresh_native_sessions"]=native_ids
    diagnosis["same_native_system_prompt"]=True
    for sid in [1,2]:
        paths=[ROOT/"tasks_generated/diagnostics/hermes-memory-link-20260916"/arm/f"memory_link_diagnostic__session_{sid}/instruction.md" for arm in ["on","off"]]
        assert paths[0].read_bytes()==paths[1].read_bytes()
    diagnosis["same_instructions_in_both_arms"]=True
    diagnosis["marker_absent_from_second_session_input_and_generated_files"]=True
    diagnosis["runtime_image"]=IMAGE
    image=json.loads(subprocess.check_output(["docker","image","inspect",IMAGE],text=True))[0]
    assert image["Id"]==read(original/"inputs/runtime-manifest.json")["docker_image_id"]
    diagnosis["same_runtime_image_as_math"]=True
    diagnosis["git_status"]=subprocess.check_output(["git","status","--short"],cwd=ROOT,text=True).strip()
    names=subprocess.check_output(["docker","ps","--format","{{.Names}}"],text=True).splitlines()
    assert not any(n.startswith("dumemeval_memory_link_diagnostic__") for n in names)
    assert not diagnosis["git_status"]
    diagnosis["owned_trial_containers_closed"]=True
    diagnosis["known_secret_scan_passed"]=True
    for name in ["marker-on.log","marker-off.log"]:
        (root/"inputs"/name).write_text(redactor.text((HERE/name).read_text(encoding="utf-8")),encoding="utf-8")
    shutil.copyfile(Path(__file__),root/"inputs/explain_zero_delta.py")
    shutil.copyfile(HERE/"run_arm.py",root/"inputs/runtime_compatibility.py")
    (root/"diagnosis.json").write_text(json.dumps(diagnosis,indent=2,ensure_ascii=False),encoding="utf-8")
    on=diagnosis["marker_controls"]["on"]
    off=diagnosis["marker_controls"]["off"]
    md=f'''# 分数相同之后的复核

## 结论

Hermes 的跨会话目录记忆通道已实际工作。原来的单条 Math 样本在 GPT-5.5（medium）上两组都能答对，不能用其零分差证明记忆有益，也不能据此判断记忆没有运行。

## 原始 Math 运行存在真实行为差异

| 原生轨迹证据 | directory | none |
| --- | ---: | ---: |
| 完成会话 | 2/2 | 2/2 |
| 记忆文件写入/更新调用 | 2 | 0 |
| 记忆 read_file 调用 | 1 | 0 |
| 全部原生工具调用 | 12 | 7 |
| 官方 paper passrate | 1.0 | 1.0 |

原始 86 份证据的哈希再次核验通过。第二会话的读取内容与第一份记忆快照一致，none 组没有记忆挂载。官方 reasoning 与 submit 都有真实返回；两个会话均由官方 judge 判为 yes。

## 为什么这条 Math 样本分数相同

第二轮题面本身包含 Construction 3.14（仿射 C∞ 概形与结构层的构造）以及 Lemma 3.17（相关理想是 Poisson 理想）。无记忆组使用当前题面与官方 reasoning 工具就答对了。

第一会话保存的笔记主要是局部化的泛性质和唯一映射；有记忆组虽读取了该笔记，第二轮发给 reasoning 的请求没有显式加入这份笔记的独有内容。因此本样本在这次模型配置下没有表现出记忆收益，不能支持“记忆普遍无用”的结论。

对无记忆组的潜在隐式传递也作了检查：官方 MathEnvironment.reasoning 每次只构造 system + 当前 task 两条消息，没有向模型传入环境的 history。题面按数据集原文 backgrounds + questions 构造，参考 answers 在宿主提交评分时提供。

- [无记忆组第二轮题面](E:/dumemeval/tasks_generated/memoryarena/hermes-controlled-20260916/off/memoryarena_math_39__session_2/instruction.md:20)
- [第一轮记忆笔记](E:/dumemeval/results/memoryarena/hermes-controlled-20260916/on/snapshots/memoryarena-hermes-on/memoryarena_math_39/session_1/cinfty_localization.md)
- [官方 reasoning 实现](E:/dumemeval/.cache/memoryarena-repro/reference/env/env_systems/math_env.py:96)

## 新增：必须依靠记忆的真实隔离诊断

在宿主随机生成一个 128-bit 标记，只在第一会话提供。第二会话使用新的容器与原生会话；提示词和生成的任务文件里都没有该标记。沿用原先的 Hermes 0.21.3、Harbor 0.22.0、DirectoryAdapter 和 GPT-5.5（medium）接口配置，两组提示词逐字相同。

| 组别 | 第二会话真实输出 | 精确找回标记 |
| --- | --- | ---: |
| directory 记忆 | `{on['second_session_answer']}` | 1/1 |
| none 无记忆 | `{off['second_session_answer']}` | 0/1 |

有记忆组第一会话通过工具将标记保存到 `memoryarena_parcels.json`；第二会话 read_file 返回的全文与第一份快照一致，最终准确输出标记。无记忆组正确地按约定输出 UNKNOWN。两组运行均完成；本诊断的回忆成绩由宿主严格字符串比较产生。

这个诊断验证了传递与检索通道，属于自行设计的功能检查，不是官方 MemoryArena 样本，也不是正式性能收益数据。

## 新增：评分器正反例

直接调用同一官方 MathEnvironment.judge 与实际模型接口：

- 正确参考答案 → yes / accepted=true。
- 明显错误答案（“Spec(A) 是恰好有七个元素的有限群”）→ no / accepted=false。

这次正反例排除了评分器在这两次请求中固定返回满分的情况，不能据此概括其全部判分准确率。

## 证据与限制

- [完整诊断 JSON](E:/dumemeval/results/diagnostics/hermes-memory-link-20260916/diagnosis.json)
- [随机标记记忆组](E:/dumemeval/results/diagnostics/hermes-memory-link-20260916/on/exact-recall.json)
- [随机标记无记忆组](E:/dumemeval/results/diagnostics/hermes-memory-link-20260916/off/exact-recall.json)
- [真实评分器正反例](E:/dumemeval/results/diagnostics/hermes-memory-link-20260916/judge-controls.json)

原有自动 read/token/cost 统计限制仍存在，已在先前验收报告说明；本次以原生轨迹和精确标记匹配核验。源码工作区没有改动，本地运行兼容处理与之前相同。原始验收证据保留，新诊断单独存放。
'''
    (root/"diagnosis.md").write_text(md,encoding="utf-8")
    redactor.tree(root)
    for p in root.rglob("*"):
        if p.is_file():
            assert not any(s.encode() in p.read_bytes() for s in redactor.secrets)
    evidence={p.relative_to(root).as_posix():sha(p) for p in sorted(root.rglob("*")) if p.is_file() and p.name!="evidence-sha256.json"}
    (root/"evidence-sha256.json").write_text(json.dumps(evidence,indent=2),encoding="utf-8")
    print(json.dumps({"passed":True,"exact_recall_on":on["exact_recall"],"exact_recall_off":off["exact_recall"],"judge_negative_control_passed":True,"artifacts_hashed":len(evidence),"report":str(root/"diagnosis.md")},ensure_ascii=False))


if __name__=="__main__":
    main()
