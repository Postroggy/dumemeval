"""Real-runtime positive/negative control for the cross-session memory channel.

This is a plumbing diagnostic with exact-match scoring, not a MemoryArena sample.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import secrets
import shutil

import yaml

from run_arm import ROOT, IMAGE, install_local_compatibility


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("arm", choices=["on", "off"])
    args = parser.parse_args()
    os.chdir(ROOT)
    root = ROOT / "results/diagnostics/hermes-memory-link-20260916"
    inputs = root / "inputs"
    inputs.mkdir(parents=True, exist_ok=True)
    nonce_path = inputs / "marker.json"
    if not nonce_path.exists():
        nonce_path.write_text(json.dumps({"marker": secrets.token_hex(16), "purpose": "non-sensitive random diagnostic marker"}, indent=2), encoding="utf-8")
    marker = json.loads(nonce_path.read_text(encoding="utf-8"))["marker"]
    assert len(marker) == 32
    assert not (root / args.arm / "summary.json").exists(), "Preserve completed attempts"

    first = (
        "This is a MemoryArena infrastructure diagnostic, outside the official benchmark. "
        "Load the persistent-memory skill. The recorded marker for parcel CobaltParcel is "
        f"{marker}. This is a non-sensitive randomly generated label. "
        "A later, fresh session will ask for that marker. If DUMEMEVAL_MEMORY_DIR is set, "
        "save this association in that directory. If it is unset, do not create any substitute "
        "persistence channel. After handling the instruction, reply with ACK only."
    )
    second = (
        "This is a MemoryArena infrastructure diagnostic, outside the official benchmark. "
        "Load the persistent-memory skill. A previous session was told a randomly generated "
        "marker for parcel CobaltParcel. What is that exact marker? You have a fresh conversation. "
        "Use only any configured persistent memory to recover it. If DUMEMEVAL_MEMORY_DIR is "
        "unset or it contains no recorded marker, reply with UNKNOWN. Do not guess or generate "
        "a new marker. Reply with only the exact recorded marker or UNKNOWN on one bare line."
    )
    assert marker not in second
    baseline = yaml.safe_load((ROOT / "results/memoryarena/hermes-controlled-20260916/inputs/controlled-math.yaml").read_text(encoding="utf-8"))
    execution = copy.deepcopy(baseline["execution"])
    execution["environment"]["agent_timeout_sec"] = 240
    assert execution["environment"]["docker_image"] == IMAGE
    cfg = {
        "experiment": {"name": "memory_link_diagnostic", "description": "Non-official random-marker memory transport diagnostic", "protocol": "memory_session_transfer" if args.arm=="on" else "test_only"},
        "agent": baseline["agent"], "execution": execution,
        "memory": {"name": "marker-"+args.arm, "type": "directory" if args.arm=="on" else "none", "path": str(root/("memory-"+args.arm))},
        "task": {"memory_instruction": "none", "sessions": [{"instruction": s, "memory_inject": args.arm=="on"} for s in [first,second]]},
        "judging": {"type": "rule"},
        "output": {"dir": str(root/args.arm), "tasks_dir": str(ROOT/"tasks_generated/diagnostics/hermes-memory-link-20260916"/args.arm)},
    }
    config_path = inputs / f"{args.arm}.yaml"
    config_path.write_text(yaml.safe_dump(cfg,sort_keys=False),encoding="utf-8")
    shutil.copyfile(Path(__file__),inputs/"probe_memory_link.py")
    proxy_path = Path("C:/Users/32144/AppData/Local/DuMemEval/cliproxyapi-7.3.2/config.yaml")
    proxy = yaml.safe_load(proxy_path.read_text(encoding="utf-8"))
    assert proxy.get("request-retry") == 0
    os.environ.update(DUMEMEVAL_PROXY_KEY=proxy["api-keys"][0], OPENAI_API_KEY=proxy["api-keys"][0], OPENAI_BASE_URL="http://host.docker.internal:8317/v1")
    install_local_compatibility()
    from dumemeval.cli import main as cli_main
    code = cli_main(["run","--config",str(config_path),"--no-resume"])
    assert code == 0, f"Runtime execution failed: {code}"
    summary = json.loads((root/args.arm/"summary.json").read_text(encoding="utf-8"))
    assert not summary["mock"]
    cp_path = root/args.arm/"checkpoints/memory_link_diagnostic.json"
    cp = json.loads(cp_path.read_text(encoding="utf-8"))
    assert len(cp["sessions"]) == 2 and all(s["success"] for s in cp["sessions"])
    answer = cp["sessions"][1]["observation"].strip()
    report = {"arm":args.arm,"execution_completed":True,"second_session_answer":answer,"exact_recall":answer==marker,
              "expected_if_channel_works":marker if args.arm=="on" else "UNKNOWN",
              "matches_expected_control":answer==(marker if args.arm=="on" else "UNKNOWN"),
              "marker_sha256":hashlib.sha256(marker.encode()).hexdigest(),"official_benchmark":False,
              "scoring":"Host-side exact string comparison; generic framework utility metrics are not this diagnostic's recall score."}
    (root/args.arm/"exact-recall.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
    print(json.dumps(report))


if __name__ == "__main__":
    main()
