"""Local-only Hermes/Harbor compatibility and bounded MemoryArena run launcher."""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys

import yaml

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
IMAGE = "dumemeval-hermes:0.21.3-control-20260916"
HERMES_COMMIT = "345cd2b057a452236de401d3534b8502a7465e8d"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def make_config() -> Path:
    cfg = yaml.safe_load((ROOT / "configs/memoryarena/controlled-math.yaml").read_text(encoding="utf-8"))
    cfg["agent"].update(runtime="hermes", version="0.21.3", model="openai/gpt-5.5(medium)",
                        setup_timeout_sec=120)
    cfg["agent"].pop("skills_dir", None)
    cfg["experiment"]["name"] = "memoryarena-math-hermes-${MEMORYARENA_ARM:-on}"
    cfg["memory"]["name"] = "memoryarena-hermes-${MEMORYARENA_ARM:-on}"
    cfg["execution"]["environment"]["docker_image"] = IMAGE
    cfg["execution"]["environment"]["env"] = {
        "OPENAI_API_KEY": "${DUMEMEVAL_PROXY_KEY}",
        "OPENAI_BASE_URL": "http://host.docker.internal:8317/v1",
        "HERMES_HOME": "/tmp/hermes",
        "TERMINAL_ENV": "local",
        "HERMES_DISABLE_LAZY_INSTALLS": "1",
    }
    path = HERE / "controlled-math.yaml"
    text = yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True)
    if not path.exists() or path.read_text(encoding="utf-8") != text:
        path.write_text(text, encoding="utf-8")
    return path


def install_local_compatibility() -> None:
    import harbor.agents.installed.hermes as hermes_module
    from harbor.agents.installed.hermes import Hermes
    from harbor.environments.base import BaseEnvironment

    async def use_pinned_preinstalled(self: Hermes, environment: BaseEnvironment) -> None:
        # Harbor 0.22's installer ends with the unsupported `hermes version`.
        # A verified image already contains the pinned official Hermes package.
        # Installation is bypassed; run() and ATIF export are untouched.
        code = (
            "import importlib.metadata,json,pathlib;"
            "v=importlib.metadata.version('hermes-agent');assert v=='0.21.3',v;"
            "d={'runtime':'hermes','version':v,'source_commit':'" + HERMES_COMMIT + "',"
            "'openai_sdk':importlib.metadata.version('openai'),'harbor_install_hook':'verified_preinstalled'};"
            "p=pathlib.Path('/logs/agent/hermes-runtime.json');"
            "p.write_text(json.dumps(d,indent=2),encoding='utf-8');print(json.dumps(d))"
        )
        await self.exec_as_agent(environment, command="/opt/hermes/.venv/bin/python -c " + shlex.quote(code),
                                 timeout_sec=30)

    Hermes.install = use_pinned_preinstalled
    Hermes.get_version_command = lambda self: "hermes --version"
    # Current Hermes requires explicit provider selection for the OpenAI key
    # and OPENAI_BASE_URL pair. Harbor 0.22 otherwise leaves provider=auto.
    hermes_module._NATIVE_PROVIDERS["openai"] = ("openai-api", ["OPENAI_API_KEY"])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("arm", choices=["on", "off"])
    parser.add_argument("--run", default="hermes-controlled-20260916")
    parser.add_argument("--prepare", action="store_true")
    args = parser.parse_args()
    os.chdir(ROOT)
    proxy_path = Path("C:/Users/32144/AppData/Local/DuMemEval/cliproxyapi-7.3.2/config.yaml")
    proxy = yaml.safe_load(proxy_path.read_text(encoding="utf-8"))
    key = proxy["api-keys"][0]
    assert proxy.get("request-retry") == 0 and proxy.get("max-retry-credentials") == 1
    sample = ROOT / ".cache/memoryarena-repro/assets/math-complete-sample.json"
    assert sha(sample) == "82a430425b49471c68a8fc8a00caffe4fd505678fb8001f785abd565a5c3b868"
    os.environ.update({
        "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8",
        "DUMEMEVAL_PROXY_KEY": key, "OPENAI_API_KEY": key,
        "OPENAI_BASE_URL": "http://host.docker.internal:8317/v1",
        "MEMORYARENA_REFERENCE": str(ROOT / ".cache/memoryarena-repro/reference"),
        "MEMORYARENA_PYTHON": sys.executable,
        "MEMORYARENA_CONTROL_SAMPLE": str(sample),
        "MEMORYARENA_CONTROL_RUN": args.run,
        "MEMORYARENA_ARM": args.arm,
        "MEMORYARENA_PROTOCOL": "memory_session_transfer" if args.arm == "on" else "test_only",
        "MEMORYARENA_MEMORY_TYPE": "directory" if args.arm == "on" else "none",
    })
    config = make_config()
    from dumemeval.cli import main as cli_main
    if args.prepare:
        sys.argv = ["dumemeval", "prepare", "--environment-config", str(config)]
        cli_main()
        return

    run_root = ROOT / "results/memoryarena" / args.run
    assert not (run_root / args.arm / "summary.json").exists(), "Use a fresh run label for a new attempt"
    image = json.loads(subprocess.check_output(["docker", "image", "inspect", IMAGE], text=True))[0]
    assert image["Config"]["Labels"]["org.opencontainers.image.revision"] == HERMES_COMMIT
    input_dir = run_root / "inputs"
    input_dir.mkdir(parents=True, exist_ok=True)
    manifest = {
        "framework_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "harbor_version": importlib.metadata.version("harbor"),
        "hermes_version": "0.21.3", "hermes_commit": HERMES_COMMIT,
        "docker_image": IMAGE, "docker_image_id": image["Id"],
        "sample_sha256": sha(sample), "config_sha256": sha(config), "launcher_sha256": sha(Path(__file__)),
        "compatibility": "Process-local install hook validates the pinned preinstalled Hermes package; version command uses --version; the native OpenAI routing table selects --provider openai-api. Official Harbor Hermes.run and export remain unchanged.",
        "skills": "The unchanged persistent-memory skill is baked into /tmp/hermes/skills in the common image; skills_dir is omitted to avoid Windows host-path normalization of a container path.",
        "model_api": "Explicit Hermes openai-api provider resolves to codex_responses via CLIProxyAPI at http://host.docker.internal:8317/v1, verified by a native Hermes preflight. The Math environment judge uses the same proxy via its OpenAI backend.",
        "native_memory": "Harbor Hermes config disables memory_enabled and user_profile_enabled in both arms",
        "observation_boundary": "Framework automatic structured Read observation is Claude-specific; Hermes native tool evidence must be checked separately.",
    }
    manifest_path = input_dir / "runtime-manifest.json"
    if manifest_path.exists():
        assert json.loads(manifest_path.read_text(encoding="utf-8")) == manifest, "Runtime inputs changed between arms"
    else:
        manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        (input_dir / config.name).write_bytes(config.read_bytes())
        (input_dir / "run_arm.py").write_bytes(Path(__file__).read_bytes())
    install_local_compatibility()
    sys.argv = ["dumemeval", "run", "--config", str(config), "--no-resume"]
    cli_main()
    summary = json.loads((run_root / args.arm / "summary.json").read_text(encoding="utf-8"))
    print(json.dumps({"arm": args.arm, "mock": summary["mock"], "tasks": summary["per_task"],
                      "benchmark": summary.get("benchmark")}, ensure_ascii=False))
    assert not summary["mock"]
    assert len(summary["per_task"]) == 1
    assert summary["per_task"][0]["n_success"] == summary["per_task"][0]["n_sessions"] == 2


if __name__ == "__main__":
    main()
