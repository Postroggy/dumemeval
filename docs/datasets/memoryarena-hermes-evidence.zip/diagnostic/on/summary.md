# DuMemEval 汇总 — memory_link_diagnostic

> 2026-09-16 00:40:52 · 1 tasks · 并行度 1

## Reproduce

```bash
uv run python -m dumemeval run --config E:\dumemeval\results\diagnostics\hermes-memory-link-20260916\inputs\on.yaml --output E:\dumemeval\results\diagnostics\hermes-memory-link-20260916\on
```

- git: `909e185 (codex/memoryarena-issue-4)`
- judging: type=rule model=n/a num_runs=1 skip_failed=False

## 跨 task 平均

- Quality: n/a（未配 ground truth）
- Utility: success_rate=1.000

## Per-task

| task | sessions | benchmark | 报告 |
|---|---|---|---|
| memory_link_diagnostic | 2/2 | - | `E:\dumemeval\results\diagnostics\hermes-memory-link-20260916\on\memory_link_diagnostic__marker-on` |
