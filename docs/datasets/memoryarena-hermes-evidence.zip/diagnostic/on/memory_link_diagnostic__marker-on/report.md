# memory_link_diagnostic — marker-on

status: completed

## Metrics
- utility.task_success: 1.0000
- utility.success_rate: 1.0000
- utility.turns: 2.0000
- utility.cost_usd: 0.0000
- utility.memory_conditioned_gain: 0.0000
- efficiency.write_latency_ms: 0.0000
- efficiency.retrieval_latency_ms: 0.0000
- efficiency.tokens_in: 0.0000
- efficiency.tokens_out: 0.0000
- efficiency.cost_usd: 0.0000
- trace.trace_captured_rate: 1.0000
- trace.empty_output_rate: 0.0000
- trace.error_rate: 0.0000
- trace.memory_tool_used: 1.0000
- trace.memory_write_ops: 1.0000

Memory observations (lower bounds): writes=1, reads=n/a. n/a means unmeasured; missing observations do not establish zero use.

## Sessions

| Session | Execution | Environment | Error |
| --- | --- | --- | --- |
| 1 | completed | not measured |  |
| 2 | completed | not measured |  |

## Artifacts

- agent_trajectory: `E:\dumemeval\results\diagnostics\hermes-memory-link-20260916\on\trials\dumemeval_memory_link_diagnostic__session_2\agent\trajectory.json`

## Reproduce

```bash
uv run python -m dumemeval run --config E:\dumemeval\results\diagnostics\hermes-memory-link-20260916\inputs\on.yaml --output E:\dumemeval\results\diagnostics\hermes-memory-link-20260916\on
```

- git: `909e185 (codex/memoryarena-issue-4)`
- judging: type=rule model=n/a num_runs=1 skip_failed=False
