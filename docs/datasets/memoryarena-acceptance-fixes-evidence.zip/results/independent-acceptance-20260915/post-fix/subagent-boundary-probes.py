"""Independent, no-model probes for scoring and pending-request boundaries."""

from __future__ import annotations

import json
import socket
import threading
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch
from uuid import uuid4

from dumemeval.artifacts.redaction import Redactor
from dumemeval.datasets.benchmarks.memoryarena_search import MemoryArenaSearchAdapter
from dumemeval.evaluation import CalculatorBenchmarkScorer, Evaluator
from dumemeval.evaluation.scorer import BenchmarkScorer
from dumemeval.metrics.core.base import MetricInput
from dumemeval.models import BenchmarkResult, SessionOutcome, TaskExecution
from dumemeval.pipeline.scoring import CheckpointedScorer, ScoringCheckpointError
from dumemeval.task_environments.agent_tool import pending_request


def main():
    root = Path(__file__).resolve().parent
    attempt = root / ('boundary-' + uuid4().hex[:10])
    attempt.mkdir()
    adapter = MemoryArenaSearchAdapter()
    task = adapter.build_tasks(adapter.data_type.from_raw([
        {'id': 901, 'questions': ['subquery', 'final combined question'], 'answers': ['sub', 'answer']}
    ]))[0]
    execution = TaskExecution(
        task_id=task.name, task_name=task.name, memory_backend='none',
        sessions=[SessionOutcome(session_id=i, success=True, observation='answer') for i in [1, 2]],
    )
    inp = MetricInput(task=task, execution=execution)
    redactor = Redactor({})
    reports = {}

    class BlockingScorer(BenchmarkScorer):
        def __init__(self):
            self.calls = 0
            self.started = threading.Event()
            self.release = threading.Event()

        def score(self, inp):
            self.calls += 1
            self.started.set()
            assert self.release.wait(10)
            return BenchmarkResult(benchmark='memoryarena_search', values={'accuracy': 1})

    blocking = BlockingScorer()
    first = CheckpointedScorer(blocking, attempt / 'concurrent', {}, redactor)
    second = CheckpointedScorer(blocking, attempt / 'concurrent', {}, redactor)
    with ThreadPoolExecutor(max_workers=2) as pool:
        running = pool.submit(first.score, inp)
        assert blocking.started.wait(5)
        try:
            second.score(inp)
            pending_blocked = False
        except ScoringCheckpointError:
            pending_blocked = True
        finally:
            blocking.release.set()
        first_result = running.result(timeout=10)
    resumed = second.score(inp)
    reports['concurrent_finalizers'] = {
        'pending_blocked': pending_blocked, 'scorer_calls': blocking.calls,
        'completed_result_reused': first_result == resumed,
    }
    assert reports['concurrent_finalizers'] == {
        'pending_blocked': True, 'scorer_calls': 1, 'completed_result_reused': True,
    }

    class FailedScorer(BenchmarkScorer):
        calls = 0
        def score(self, inp):
            self.calls += 1
            raise RuntimeError('fixture: response lost after judging')

    failing = FailedScorer()
    try:
        CheckpointedScorer(failing, attempt / 'failed', {}, redactor).score(inp)
    except RuntimeError:
        pass
    try:
        CheckpointedScorer(failing, attempt / 'failed', {}, redactor).score(inp)
        blocked = False
    except ScoringCheckpointError:
        blocked = True
    reports['failed_scorer_resume'] = {'blocked': blocked, 'scorer_calls': failing.calls}
    assert blocked and failing.calls == 1

    pending = attempt / 'pending.json'
    initial = json.loads(pending_request(pending, 'action', {'flag': True}, 'stable-id'))
    try:
        returned = json.loads(pending_request(pending, 'action', {'flag': 1}, None))
        reports['different_json_arguments'] = {
            'rejected': False, 'initial': initial['arguments'], 'requested': {'flag': 1},
            'returned': returned['arguments'],
        }
    except SystemExit:
        reports['different_json_arguments'] = {'rejected': True}

    deliveries = []

    class JudgeEndpoint(BaseHTTPRequestHandler):
        def do_POST(self):
            payload = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
            deliveries.append({'path': self.path, 'payload': payload})
            if len(deliveries) == 1:
                self.close_connection = True
                self.connection.shutdown(socket.SHUT_RDWR)
                self.connection.close()
                return
            body = json.dumps({
                'id': 'resp_local_fixture', 'object': 'response', 'created_at': 0,
                'status': 'completed', 'model': 'local-fixture',
                'output': [{'id': 'msg_fixture', 'type': 'message', 'status': 'completed',
                            'role': 'assistant', 'content': [{'type': 'output_text',
                                'text': 'correct: yes\nconfidence: 100%', 'annotations': []}]}],
            }).encode()
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *args):
            pass

    server = ThreadingHTTPServer(('127.0.0.1', 0), JudgeEndpoint)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        config = {
            'provider': 'openai', 'model': 'local-fixture', 'api_key_env': 'AUDIT_FIXTURE_KEY',
            'base_url': f'http://127.0.0.1:{server.server_port}', 'max_retries': 1,
        }
        calculator = CalculatorBenchmarkScorer('memoryarena_search', llm_config=config)
        scorer = CheckpointedScorer(calculator, attempt / 'sdk-retry', config, redactor)
        with patch.dict('os.environ', {'AUDIT_FIXTURE_KEY': 'public-local-fixture-key'}):
            result = Evaluator(None, scorer).evaluate(task, execution)
            after_first = len(deliveries)
            repeated = Evaluator(None, scorer).evaluate(task, execution)
        reports['judge_response_lost'] = {
            'configured_framework_max_retries': 1,
            'endpoint_deliveries_after_first_score': after_first,
            'endpoint_deliveries_after_resume': len(deliveries),
            'same_request_body': len(deliveries) >= 2 and deliveries[0] == deliveries[1],
            'accuracy': result.benchmark.values.get('accuracy'),
            'resumed_result_equal': result.benchmark == repeated.benchmark,
        }
    finally:
        server.shutdown()
        thread.join(5)
        server.server_close()

    report = {'model_calls': 0, 'official_environment_calls': 0, 'probes': reports, 'artifacts': str(attempt)}
    (root / 'subagent-boundary-probes.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
