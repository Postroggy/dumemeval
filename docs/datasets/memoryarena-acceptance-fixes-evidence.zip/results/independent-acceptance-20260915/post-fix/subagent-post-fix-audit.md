# MemoryArena issue #4：独立修复后复验

日期：2026-09-15；工程：`E:\dumemeval`；审计者：独立 subagent。原始 HEAD 为 `37a0e1959e14509898fca856d8fd3fd2a720aefb`，验收对象是当前本地改动。

**当前独立审计发现的验收阻塞均已关闭。15 项在用户约定的最小跑通验证范围内可以判为通过。** 原始失败报告保留在 [subagent-audit.md](E:/dumemeval/results/independent-acceptance-20260915/subagent-audit.md)，不能用新结论倒改当时的失败事实。

本次只读审查生产源码，运行固定 fixture、真实本地 HTTP 服务及离线反例。没有调用真实模型，没有运行全量评测，没有提交或推送。新增审计文件均在 ignored results 目录中。

## 逐项结论

| # | 验收标准 | 复验结论与证据 |
| --- | --- | --- |
| 1 | 五场景固定官方版本及入口、数据、环境、评分、许可证 | 通过。[来源清单](E:/dumemeval/docs/datasets/memoryarena-sources.json)和[集成说明](E:/dumemeval/docs/datasets/memoryarena.md)保留代码 `6cd9de14...`、数据 `da1a37c8...`、入口、环境及许可状态。未知许可明确标注。独立核对新 reference 的 HEAD 与固定值一致。 |
| 2 | 五场景统一评测入口 | 通过。[五场景 CLI fixture](E:/dumemeval/tests/test_memoryarena_cli.py)重新通过，且运行前显式移除本机 MEMORYARENA_JAVA_HOME，排除环境偶然补齐配置的影响。CLI fixture 使用 mock；真实 Math Agent 和各场景官方工具/HTTP 证据的范围沿用原审计。 |
| 3 | 官方任务组织及评分语义 | 通过。Search 只判原始最后组合问题、每个完整 query 等权聚合。[计算器](E:/dumemeval/src/dumemeval/metrics/benchmarks/memoryarena_search.py:46)已修复；独立执行 pinned 官方 summary 函数对照 `[错,对]→1`、`[对,错]→0`，见[原反例修复后结果](E:/dumemeval/results/independent-acceptance-20260915/post-fix/final/subagent-scorer-probes.json)。最新 29 项官方 parity 通过。 |
| 4 | 至少一个真实环境加 Agent 交互 | 通过。原审计已独立核查 [controlled-final-20260915](E:/dumemeval/results/memoryarena/controlled-final-20260915) 的 4 个真实 Claude Code/GPT-5.5 会话、官方工具、submit、成功状态和清理。该真实模型实验为历史运行；此次修复以最新本地 fixture 回归验证。 |
| 5 | 多轮及跨 session memory | 通过。同一完整 Math row 39 有两轮；on 第一轮写入，第二个新会话结构化读取并更新，快照及哈希链相符。见[真实任务结果](E:/dumemeval/results/memoryarena/controlled-final-20260915/on/memoryarena_math_39__memoryarena-on/result.json)。操作计数的观测下限已说明。 |
| 6 | environment/session/memory reset 边界 | 通过。原审计的环境 step 0→1→2、独立 conversation ID、memory 生命周期证据继续有效。本轮新增真实 managed Math/OpenAI、Phys/Anthropic 服务测试在 reset 后确认 SDK 策略仍有效；任务、会话 capability、目录 memory 的职责未合并。 |
| 7 | on/off 控制变量和样本对齐 | 通过，限定已执行 Math 对照。原审计核查两臂 9 个控制指纹相同，两轮 instruction 分别逐字节相同，四个真实会话 ID 不同。官方分数均 1，差值 0；没有记忆收益或统计显著性结论。Shopping wall-clock seed 限制仍明确记录。 |
| 8 | 五场景 fixture 或 scorer 不可运行原因 | 通过。[固定输入](E:/dumemeval/tests/fixtures/memoryarena/cases.json)及[官方 parity](E:/dumemeval/tests/test_memoryarena_official_parity.py)本轮 29 项通过，新增 Search 最终 query 聚合覆盖补齐原缺口。 |
| 9 | 官方分数、judge、derived metrics、execution 分离 | 通过。数据结构继续区分 benchmark/metrics/samples/execution；judge 证据及 official_score 分开保存，Harbor reward 不代替官方分数。Search 新实现保留 score_status、judge_observation 和官方最终 query accuracy。 |
| 10 | 失败、超时、跳过、未测与 0 可区分 | 通过。原反例截掉最后问题后现在 accuracy=null；最终答错仍为 0。新实际 SDK 丢响应测试产生 not_measured，并在 resume 复用该未测记录，未伪造 0 分。见[独立边界结果](E:/dumemeval/results/independent-acceptance-20260915/post-fix/final/subagent-boundary-probes.json)。 |
| 11 | 重试不会重复 memory write、动作或评分 | 通过，针对同一逻辑操作/同一执行证据的重试。[客户端](E:/dumemeval/src/dumemeval/task_environments/agent_tool.py)持久 pending ID、OS 锁、显式 request ID，按 canonical JSON 绑定参数；[gateway](E:/dumemeval/src/dumemeval/task_environments/gateway.py)缓存成功和异常。[评分 checkpoint](E:/dumemeval/src/dumemeval/pipeline/scoring.py)在请求前占位，完成后持久化，损坏/未完成时禁止自动重放。独立并发与失败恢复均仅 1 次 scorer 调用；真实 runner resume 的 judge 计数 1→1。框架 SDK 禁隐式重试、显式 429 才自动重试，官方 Math/Phys factory 配置同样关闭 SDK 重放；丢响应仅送达 1 次，gateway 重试仍 1 次。 |
| 12 | trace/provenance 完整且脱敏 | 通过，限定交付证据和明确观测范围。原审计核对 107 个 artifact SHA、四份 native/ATIF 会话、两份环境 trace、memory 操作及快照关联。评分缓存先脱敏再持久化，首次返回与缓存命中一致。新增 worker SDK 策略会记录，且对不适用的独立 Shopping worker 不作同一承诺。 |
| 13 | JSON 可解析、Markdown 可读 | 通过。原交付文件及 archive 的解析/CRC 验证保留；本轮新审计结果为可解析 JSON，测试输出完整，报告明确区分修复前后证据。 |
| 14 | 核心执行链无大量场景/backend 分支 | 通过。Search 专属规则在其 calculator；通用 durable scorer 包装 BenchmarkScorer，未加入 Search 专属 pipeline 分支；SDK 策略在自有 worker factory 边界配置，未修改官方源码。原 registry、task runtime、executor decorator 边界保留。 |
| 15 | 干净环境复现命令及未完成项 | 通过，按文档明确的前置条件及验证边界。[clean guide](E:/dumemeval/docs/datasets/memoryarena-clean-setup.md)补齐 isolated venv、固定 CLIProxyAPI 下载/哈希/私有配置/交互登录/启动、固定原生镜像、官方 checkout 与固定样本准备、两臂统一命令。独立核查 fresh venv 的 122 包 pip check、Python 3.12.11、reference HEAD、样本 SHA、镜像 ID，并原样运行 Docker→host 401 routing 命令成功。新账号交互登录和原生 Linux 主机部署未重跑，文档明确标记；无需使用作者现有秘密或 E:\tmp 资产才能依步骤准备。 |

## 独立复验发现并关闭的追加问题

首次修复解决了 Search 聚合、截断、CLI 环境 fixture 和外层评分 resume，但独立故障注入又发现两项残留：

1. 实际 OpenAI SDK 在评分响应丢失后仍隐式重复请求。框架配置 max_retries=1 时同一 score 产生 2 次端点送达；固定官方 Math backend 也有相同行为。修复前证据见 [boundary-probes.json](E:/dumemeval/results/independent-acceptance-20260915/post-fix/subagent-boundary-probes.json)与[official-sdk-probe.json](E:/dumemeval/results/independent-acceptance-20260915/post-fix/subagent-official-sdk-probe.json)。修复后即使框架配置 max_retries=3，独立本地端点仍只收到 1 次请求，resume 仍为 1，分数明确未测。最新实际 managed worker 测试覆盖 OpenAI 和 Anthropic。
2. pending 参数使用 Python dict 相等比较，把 JSON true 与 1 视为相同。独立反例曾把请求 `{flag:1}`错误恢复为 `{flag:true}`。改用 canonical JSON 后相异参数被拒绝；修复前后结果分别保存在上述 boundary 和 final/boundary 文件。

## 本次实际执行的检查

最新独立 fresh venv 回归：**110 passed，37.43 秒，0 skipped**；[完整输出](E:/dumemeval/results/independent-acceptance-20260915/post-fix/final/independent-tests.txt)。执行前清除 MEMORYARENA_JAVA_HOME，MEMORYARENA_REFERENCE 指向新的 `.cache/memoryarena-repro/reference`。

```powershell
$env:PYTHONUTF8='1'
$env:PYTHONIOENCODING='utf-8'
Remove-Item Env:MEMORYARENA_JAVA_HOME -ErrorAction SilentlyContinue
$env:MEMORYARENA_REFERENCE='E:\dumemeval\.cache\memoryarena-repro\reference'
& .cache/memoryarena-repro/venv/Scripts/python.exe -m pytest tests/test_memoryarena_judge_retry.py tests/test_memoryarena_search_scoring.py tests/test_memoryarena_tool_retry.py tests/test_scoring_checkpoint.py tests/test_memoryarena_cli.py tests/test_memoryarena_official_parity.py tests/test_verifier.py tests/test_verifier_clients.py tests/test_judge_config.py tests/test_judge_robustness.py tests/test_retry.py -q
```

另外独立执行以下脚本，模型调用均为 0；脚本和结果一同保留，可用于后续修复回归：

- [最终 query/scorer resume 反例](E:/dumemeval/results/independent-acceptance-20260915/post-fix/final/subagent-scorer-probes.py)。
- [并发 checkpoint、失败恢复、参数类型及 SDK 丢响应反例](E:/dumemeval/results/independent-acceptance-20260915/post-fix/final/subagent-boundary-probes.py)。
- [未修改官方 backend 的原始 SDK 反例](E:/dumemeval/results/independent-acceptance-20260915/post-fix/subagent-official-sdk-probe.py)。该脚本直接加载官方 backend，故仍展示原 SDK 默认行为；新回归通过 managed worker 路径验证自有 factory 策略。两者不能混淆。

较早独立新功能回归为 59 passed；原始审计 103 项检查和故障证据也全部保留。父代理另执行 fresh venv 138 项、模块依赖 2 项、Linux 容器工具重试，已读取其日志/结果；这些不冒充本 subagent 的独立执行次数。最新 bootstrap 源码上，父代理又补跑 [runtime 与模块依赖 8 项](E:/dumemeval/results/independent-acceptance-20260915/post-fix/final/runtime-layering-tests.txt)，全部通过，31.80 秒，包含既有实际 Math/Phys 成功 HTTP 路径。110 项独立检查中的真实 worker 网络验证是新增的丢响应故障路径。

## 验证边界

真实模型与 memory-on/off 证据来自保留的四会话历史 Math 实验。最新代码的故障恢复和评分规则由固定官方函数、真实本地 HTTP 服务、Windows 客户端及离线模型端点 fixture 验证。本次没有再产生模型费用。五场景均有统一入口及官方语义/工具证据；完整数据集、五场景全量真实模型运行、原生 Linux 从零部署、全新账号登录不在已实测结论内。官方 Shopping 的随机性和 1,000 产品 transport 子集，以及 memory 观测下限继续作为明确限制保存。
