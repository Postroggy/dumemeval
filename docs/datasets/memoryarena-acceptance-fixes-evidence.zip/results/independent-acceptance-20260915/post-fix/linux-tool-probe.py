"""Run the same lost-response CLI counterexample in fresh Linux containers."""

import json
import subprocess
import tempfile
from pathlib import Path
from unittest.mock import patch

from tests.test_memoryarena_tool_retry import test_process_retry_has_one_effect

IMAGE = "dumemeval-claude:2.1.89-repro"
original_run = subprocess.run
invocations = 0


def docker_run(command, *, env, capture_output, text, timeout):
    global invocations
    invocations += 1
    environment = dict(env)
    state = environment["DUMEMEVAL_TOOL_STATE_DIR"]
    environment["DUMEMEVAL_TOOL_STATE_DIR"] = "/state"
    environment["DUMEMEVAL_TOOL_URL"] = environment["DUMEMEVAL_TOOL_URL"].replace(
        "127.0.0.1", "host.docker.internal"
    )
    args = [
        "docker", "run", "--rm",
        "-v", f"{Path(command[1]).resolve()}:/opt/arena_tool.py:ro",
        "-v", f"{state}:/state",
    ]
    for name in ("DUMEMEVAL_TOOL_STATE_DIR", "DUMEMEVAL_TOOL_URL", "DUMEMEVAL_TOOL_TOKEN", "DUMEMEVAL_TOOL_TIMEOUT"):
        args.extend(["-e", name])
    args.extend([IMAGE, "python", "/opt/arena_tool.py", *command[2:]])
    return original_run(args, env=environment, capture_output=capture_output, text=text, timeout=60)


if __name__ == "__main__":
    with tempfile.TemporaryDirectory(prefix="arena-linux-retry-") as directory:
        with patch("subprocess.run", side_effect=docker_run):
            test_process_retry_has_one_effect(Path(directory), "disconnect")
    report = {
        "status": "passed",
        "probe": "Gateway response lost, same pending command retried in another Linux process/container",
        "retry_effect_count": 1,
        "explicit_id_replay_effect_count": 1,
        "intentional_next_action_effect_count": 2,
        "container_invocations": invocations,
        "model_calls": 0,
        "image": IMAGE,
    }
    Path(__file__).with_suffix(".json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
