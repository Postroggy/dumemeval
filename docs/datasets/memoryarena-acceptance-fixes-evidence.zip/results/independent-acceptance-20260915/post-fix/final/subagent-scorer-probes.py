"""Read-only production-code audit: fixed scorer inputs and a local judge counter.

Run from E:/dumemeval with .venv/Scripts/python.exe. No model or network calls.
All generated reports live next to this script in a fresh probe attempt directory.
"""

from __future__ import annotations

import ast
import asyncio
import json
from pathlib import Path
from unittest.mock import patch
from uuid import uuid4

from dumemeval.adapters.none import NoneMemoryAdapter
from dumemeval.core.config import ExperimentConfig
from dumemeval.datasets.benchmarks.memoryarena_search import MemoryArenaSearchAdapter
from dumemeval.execution.executor import SessionExecutor
from dumemeval.lifecycle.parallel import ParallelTaskRunner
from dumemeval.metrics.benchmarks.memoryarena_search import MemoryArenaSearchCalculator
from dumemeval.metrics.core.base import MetricInput
from dumemeval.models import MemorySpec, SampleResult, SessionOutcome, TaskExecution
from dumemeval.pipeline import finalize_run
from dumemeval.verifier.base import Verdict


def main() -> None:
    root = Path(__file__).resolve().parent
    upstream = Path("E:/tmp/memoryarena-issue4-ref/run_search.py")
    tree = ast.parse(upstream.read_text(encoding="utf-8"))
    function = next(
        node for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "_summarize_single_result"
    )
    module = ast.fix_missing_locations(ast.Module(
        body=[*ast.parse("from __future__ import annotations").body, function], type_ignores=[]
    ))
    namespace = {}
    exec(compile(module, str(upstream), "exec"), namespace)

    adapter = MemoryArenaSearchAdapter()
    task = adapter.build_tasks(adapter.data_type.from_raw([
        {"id": 73, "questions": ["subquery", "final query"], "answers": ["a", "b"]}
    ]))[0]

    def metric_input(selected_task, flags):
        execution = TaskExecution(
            task_id=selected_task.name, task_name=selected_task.name, memory_backend="none",
            sessions=[
                SessionOutcome(session_id=index + 1, success=True, observation="yes" if correct else "no")
                for index, correct in enumerate(flags)
            ],
        )
        return MetricInput(
            task=selected_task, execution=execution,
            samples=[SampleResult(
                sample_id=str(session.session_id), session_id=session.session_id,
                query=selected_task.sessions[session.session_id - 1].query,
                response=session.observation,
            ) for session in execution.sessions],
        )

    parity = []
    for flags in ((False, True), (True, False)):
        actual = MemoryArenaSearchCalculator(judge=lambda prediction, *_: prediction == "yes").calculate(
            metric_input(task, flags)
        )
        expected = namespace["_summarize_single_result"]({
            "query_id": 73, "judgement": {"correct": flags[-1]}
        })
        parity.append({
            "round_correctness": list(flags),
            "current_official_accuracy": actual.values["accuracy"],
            "pinned_official_accuracy": expected["accuracy"],
        })
    truncated = adapter.build_tasks(adapter.data_type.from_raw([
        {"id": 74, "questions": ["subquery one", "subquery two", "final query"], "answers": ["a", "b", "c"]}
    ]), max_questions=2)[0]
    truncated_metric = MemoryArenaSearchCalculator(judge=lambda *_: True).calculate(metric_input(truncated, (True, True)))

    attempt = root / ("resume-" + uuid4().hex[:10])
    cfg = ExperimentConfig.model_validate({
        "experiment": {"name": "audit-search-resume", "protocol": "memory_session_transfer"},
        "memory": {"name": "none", "type": "none"},
        "task": {"sessions": [{"instruction": "s"}, {"instruction": "f"}]},
        "judging": {"type": "rule"},
        "output": {"dir": str(attempt), "tasks_dir": str(attempt / "tasks")},
    })
    counts = {"agent": 0, "judge": 0}

    class FixedAgent(SessionExecutor):
        async def run_session(self, session, session_ctx):
            counts["agent"] += 1
            return SessionOutcome(session_id=session.id, success=True, observation="fixed answer")

    class FixedJudge:
        def verify(self, *args, **kwargs):
            counts["judge"] += 1
            return Verdict(label="PASS", raw=(
                "extracted_final_answer: b\nreasoning: fixture\ncorrect: yes\nconfidence: 100%"
            ))

    runner = ParallelTaskRunner(
        lambda _: NoneMemoryAdapter(MemorySpec(name="none", type="none")),
        FixedAgent(), output_dir=attempt, resume=True,
    )
    records = []
    with patch("dumemeval.verifier.make_llm_judge", return_value=FixedJudge()):
        for index in range(2):
            execution = asyncio.run(runner.run([task]))
            finalize_run(cfg, [task], execution, adapters=runner.adapters, output_dir=attempt)
            records.append({"attempt": index + 1, **counts})

    report = {
        "source": "Actual calculator and pipeline; AST-extracted pinned official final-query summary",
        "search_final_aggregation": parity,
        "truncated_before_final": {
            "source_round_count": truncated.data["source_round_count"],
            "executed_round_count": len(truncated.sessions),
            "current_official_accuracy": truncated_metric.values.get("accuracy"),
            "expected_official_accuracy": None,
        },
        "resume_judge_counts": records,
        "resume_artifacts": str(attempt),
        "model_calls": 0,
    }
    (root / "subagent-scorer-probes.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report))


if __name__ == "__main__":
    main()
