"""No-model fault injection into the pinned official Math/Phys LLM backend."""

import importlib.util
import json
import socket
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


def main():
    deliveries = []

    class Endpoint(BaseHTTPRequestHandler):
        def do_POST(self):
            request = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
            deliveries.append(request)
            if len(deliveries) == 1:
                self.close_connection = True
                self.connection.shutdown(socket.SHUT_RDWR)
                self.connection.close()
                return
            body = json.dumps({
                'id': 'chatcmpl-fixture', 'object': 'chat.completion', 'created': 0,
                'model': 'local-fixture', 'choices': [{'index': 0, 'finish_reason': 'stop',
                    'message': {'role': 'assistant', 'content': 'yes'}}],
            }).encode()
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *args):
            pass

    server = ThreadingHTTPServer(('127.0.0.1', 0), Endpoint)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        source = Path('E:/tmp/memoryarena-issue4-ref/env/env_systems/formal_reasoning_env/llm_backend.py')
        spec = importlib.util.spec_from_file_location('audit_pinned_official_backend', source)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        backend = module.OpenAIBackend(
            model_name='local-fixture', api_key='public-fixture-key',
            base_url=f'http://127.0.0.1:{server.server_port}/v1',
        )
        result = backend.chat([{'role': 'user', 'content': 'Judge fixture answer once.'}])
        report = {
            'source': str(source), 'result': result, 'endpoint_deliveries': len(deliveries),
            'same_request_body': len(deliveries) == 2 and deliveries[0] == deliveries[1],
            'model_calls': 0, 'note': 'Unmodified pinned official backend; first accepted response lost.',
        }
        Path(__file__).with_suffix('.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
        print(json.dumps(report, indent=2))
    finally:
        server.shutdown()
        thread.join(5)
        server.server_close()


if __name__ == '__main__':
    main()
