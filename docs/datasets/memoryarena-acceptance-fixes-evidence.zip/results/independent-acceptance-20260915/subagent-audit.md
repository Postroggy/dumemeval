# MemoryArena issue #4 独立验收审计

审计日期：2026-09-15。工程：`E:\dumemeval`，本地未提交实现；原始 HEAD `37a0e1959e14509898fca856d8fd3fd2a720aefb`。

**结论：目前不能认定全部验收通过。15 项中，11 项通过、2 项部分通过、2 项未通过。** 真实 Math 联调和记忆证据成立；阻塞集中在 Search 官方评分语义、重试安全，以及干净环境复现/测试材料。无需全量评测即可修复和补验。

本审计重新读取[原 issue](https://github.com/Postroggy/dumemeval/issues/4)，检查当前源码、固定官方源码和真实 artifact，未把此前“完成”声明当证据。未修改产品源码、未提交/推送、未调用模型、未运行全量评测。所有新增文件均在 ignored `results/independent-acceptance-20260915` 下。

## 逐项结论

| # | 验收标准 | 结论 | 可核查证据与边界 |
| --- | --- | --- | --- |
| 1 | 五场景锁定官方版本，并记录入口、数据、环境、评分、许可证 | 通过 | [来源清单](E:/dumemeval/docs/datasets/memoryarena-sources.json)锁定代码 `6cd9de14...`、HF 数据 `da1a37c8...`，记录四个 runner、五场景共享/独立环境和关键文件 SHA。未指定的许可证明确写 unspecified，没有假称开源授权。场景差异见 [integration](E:/dumemeval/docs/datasets/memoryarena.md)。 |
| 2 | 五场景通过统一入口运行 | 通过（有验证边界） | [CLI 测试](E:/dumemeval/tests/test_memoryarena_cli.py:30)在固定数据、显式 mock 下验证统一入口；补齐测试遗漏的 Java 环境变量后 11 项通过。Math 有真实 Harbor 全链路；Travel/Shopping/Search 有实际官方工具 transport fixture；Phys 有实际官方 HTTP fixture。没有声称五场景均跑了真实 Agent。Shopping fixture 的环境变量遗漏另记第 15 项。 |
| 3 | 保留官方任务组织和评分语义 | **未通过** | Search 把所有子问题与最后组合问题的正确率平均作为官方 accuracy，[计算器](E:/dumemeval/src/dumemeval/metrics/benchmarks/memoryarena_search.py:49)。官方只对最终组合问题生成该 query ID 的 judgement，再跨 query ID 聚合：[官方环境](E:/tmp/memoryarena-issue4-ref/env/env_systems/browsecomp_plus_env.py:233)、[官方 runner](E:/tmp/memoryarena-issue4-ref/run_search.py:371)。固定反例 `[错,对]` 当前 0.5、官方 1；`[对,错]` 当前 0.5、官方 0。其余场景的已测规则/Math paper 聚合未见此类不一致。 |
| 4 | 至少一个环境场景真实启动并完成 Agent 交互 | 通过 | [真实 on/off 根目录](E:/dumemeval/results/memoryarena/controlled-final-20260915)包含四个 native Claude Code 2.1.89 / gpt-5.5 会话；每臂两个 reasoning 工具调用及两个官方 submit/step；四次 execution.success=true，environment close 完成，mock=false。 |
| 5 | 至少一个场景多轮 memory、至少一个跨 session memory | 通过 | 同一完整 Math row 两轮；on/session 1 有文件 add，session 2 有结构化 Read 和 replace，快照 SHA 链成立。见 [任务结果](E:/dumemeval/results/memoryarena/controlled-final-20260915/on/memoryarena_math_39__memoryarena-on/result.json)及两个 snapshot。四个 native conversation ID 互异。 |
| 6 | 三类 reset 边界可验证 | 通过（当前任务作用域） | [环境 reset](E:/dumemeval/src/dumemeval/task_environments/memoryarena.py:70)仅调用官方环境；[runtime](E:/dumemeval/src/dumemeval/task_environments/runtime.py:75)每 task 初始化/reset，而 begin_session 只切能力 token。真实 trace step 0→1→2证明换会话不清环境；native ID 证明会话换新；[Directory.setup](E:/dumemeval/src/dumemeval/adapters/directory.py:44)重建 memory 起点，[parallel](E:/dumemeval/src/dumemeval/lifecycle/parallel.py:113)按 attempt 隔离 transfer。实际 HTTP reset、过期 capability、取消/清理等定向测试通过。这不是任意后端 reset 的承诺。 |
| 7 | memory-on/off 控制变量及样本对齐 | 通过（Math 实验） | 独立比较两臂 summary.provenance.controls，9 个指纹完全相同；两份 session instruction.md 分别逐字节相同；同一完整 row、同一模型/版本、四个独立会话。观察到 on 的目录及读写，off 没有 memory mount/操作。双方分数 1.0、差值 0，不构成记忆收益结论。Shopping 的 wall-clock 随机性没有被算作受控实验。 |
| 8 | 五场景固定 fixture 或 scorer 无法本地跑的原因 | 通过 | [cases.json](E:/dumemeval/tests/fixtures/memoryarena/cases.json)、[official parity](E:/dumemeval/tests/test_memoryarena_official_parity.py)共 28 项重新运行通过，覆盖 Shopping、Travel、Search parser、Math/Phys judge parser 和 reasoning 聚合。注意 fixture“存在且通过”不证明所有聚合语义正确；第 3 项反例正是原 parity 覆盖缺口。 |
| 9 | 官方分数、judge、derived metrics、execution 分离 | 通过（结构层面） | TaskResult 分 execution / samples / benchmark / metrics；[EnvironmentEvidence](E:/dumemeval/src/dumemeval/models/environment.py:28)保留 reward/source/status；官方明细含 official_score、judge_observation，报告另列 Metrics 与 Sessions。没有用 Harbor no-op reward 当官方正确率。Search accuracy 的计算错误单列第 3 项。 |
| 10 | 失败、超时、跳过、未测与 0 分可区分 | **部分通过** | 103 项中失败/超时/ambiguous/缺 judge 与 measured zero 的针对测试通过；真实报告也区分执行状态和官方分数。但 Search `max_questions=2` 从三轮样本截掉最终问题后，两个子问题全对仍输出官方 accuracy=1.0，实际最终任务未测。计算器未根据 `source_round_count` 阻止该官方分数。 |
| 11 | 重试无重复 memory write、动作和评分 | **未通过** | 同 request ID 缓存和 ambiguous 官方 POST 禁止重放已实现；但 mounted client 每次进程生成新 ID、没有复用接口。实际丢响应后重启同一 CLI，动作执行 2 次，见[父代理复现](E:/dumemeval/results/independent-acceptance-20260915/client-retry-probe.json)。另外独立运行真实 ParallelTaskRunner(resume=True)+finalize_run，第二次 Agent 调用维持 2，而 judge 计数由 2 增至 4；缓存只存 TaskExecution，评分没有恢复。 |
| 12 | Harbor/env/memory/provenance trace 完整且脱敏 | 通过（交付证据范围） | 验收 manifest 的 107 个文件全部存在且 SHA 匹配；实际四份 ATIF/native 会话、两份环境 trace、on memory 快照/operation、provenance 都能关联；已知 credential redaction 回归通过。zip 有 113 条目（含补充 manifest），CRC 正常。本结论是对选择交付的实际证据，不保证任意未知 secret 格式或所有 shell memory 操作均可观测；后者已标 lower bound。 |
| 13 | JSON 可解析、Markdown 可阅读 | 通过 | manifest 所指 JSON/JSONL 独立逐文件/逐行解析成功；报告、comparison、验收 Markdown 有明确状态、表格和边界。zip SHA 为 `46937f2cb9dbaf731b17a3ef726caede54f125ad6468a4d4e7425495ed61fad3`，CRC 正常。 |
| 14 | 核心链无堆积 benchmark/backend 特殊分支 | 通过 | SessionRunner 通过通用 executor/adapter/protocol 协作；[EnvironmentExecutor](E:/dumemeval/src/dumemeval/execution/environment.py:35)通过 registry 创建 task runtime；场景专属行为集中在 [scenarios.py](E:/dumemeval/src/dumemeval/task_environments/scenarios.py:61)与独立官方 worker 边界。两个模块依赖测试重新通过。 |
| 15 | 文档命令在干净环境可复现，未完成项标明 | **部分通过** | 源码 clone/reference 校验、资产下载/worker lock/image Dockerfile 都有材料，Windows/Shopping 子集/未跑全量等限制有标注。但 [proxy guide](E:/dumemeval/docs/datasets/memoryarena-cliproxyapi.md:105)显式依赖现有本机 private proxy/预建镜像，未提供从零建立代理配置、认证和启动的完整可执行步骤；没有独立干净环境端到端复现证据。此外当前 CLI 测试在无 MEMORYARENA_JAVA_HOME 时实测新增 3 个失败；这些不是原仓库 migration baseline。 |

## 阻塞问题与最小修复边界

1. **[P1] Search 官方 accuracy 口径错误并允许截断冒充完整结果。** 修改 [memoryarena_search.py:80](E:/dumemeval/src/dumemeval/metrics/benchmarks/memoryarena_search.py:80)：最终组合问题决定官方 query 准确率；逐轮正确率另标 derived/progress。保留完整轮次身份，截掉最终问题则官方分数未测。补最终问题与子问题结果相反、以及截断的固定 parity fixture。无须再跑整个评测集。
2. **[P1] 工具 CLI 不能安全恢复一次丢响应的动作。** [agent_tool.py:15](E:/dumemeval/src/dumemeval/task_environments/agent_tool.py:15)每次生成新 ID；[gateway.py:80](E:/dumemeval/src/dumemeval/task_environments/gateway.py:80)只识别同 ID。需要可复用的逻辑操作 ID/投递记录并验证动作与 payload 绑定，再用同一响应丢失 fixture 验收。当前文字“不要重复”不等于支持安全重试。
3. **[P2] resume 重复 Search judge。** [parallel.py:108](E:/dumemeval/src/dumemeval/lifecycle/parallel.py:108)返回执行 checkpoint 后，[pipeline/__init__.py:107](E:/dumemeval/src/dumemeval/pipeline/__init__.py:107)仍无条件 evaluate，[evaluator.py:47](E:/dumemeval/src/dumemeval/evaluation/evaluator.py:47)重新 scorer.score。应按任务、预测、官方版本及 judge 配置缓存/恢复判分结果，避免二次收费和分数漂移。
4. **[P2] 测试与干净复现材料未闭合。** [shopping.yaml:34](E:/dumemeval/configs/memoryarena/shopping.yaml:34)新增必填 MEMORYARENA_JAVA_HOME，但 [template_env fixture:16](E:/dumemeval/tests/test_memoryarena_cli.py:16)未提供 mock 需要的占位值；补齐测试 fixture。补代理与镜像从零准备命令、明确前置软件与必须自备的模型凭据，再用独立临时安装环境做最小复现。无需接入新 runtime/backend 或全量模型评测。

## 本次实际验证

- 103 项：`test_memoryarena_official_parity.py`、`test_memoryarena_runtime.py`、`test_memoryarena_contracts.py`、`test_memoryarena_completion.py`、`test_memoryarena_client.py`、`test_memory_observation.py`，**全部通过，48.92 秒**；设置固定 `MEMORYARENA_REFERENCE`，三项官方 Math/Phys HTTP 测试使用本地 fixture judge，无外部模型。
- `test_memoryarena_cli.py` + `test_module_dependency.py`：无 MEMORYARENA_JAVA_HOME 时 **3 failed, 10 passed，4.55 秒**。提供不参与执行的 mock 占位值后 **13 passed，4.34 秒**。详细命令和错误摘录见 [测试记录](E:/dumemeval/results/independent-acceptance-20260915/subagent-test-record.txt)。
- [可重复离线 probe 脚本](E:/dumemeval/results/independent-acceptance-20260915/subagent-scorer-probes.py)与[结果 JSON](E:/dumemeval/results/independent-acceptance-20260915/subagent-scorer-probes.json)：固定 scorer 反例、truncation、真实 pipeline resume 计数。模型调用为 0。脚本通过 AST 直接执行 pinned 官方 `_summarize_single_result`，不是自行编造预期 scorer。
- 107 个 artifact SHA 全部一致；没有缺失、损坏 JSON 或 zip CRC 错误。两臂 9 个控制指纹一致，两轮 instruction 分别逐字节相同；四个 native 会话 ID 均不同。

此前“全部验收通过”的表述需要收回，改为：**真实最小联调已通过，但严格 issue 验收尚有上述评分、重试与交付缺口。**
