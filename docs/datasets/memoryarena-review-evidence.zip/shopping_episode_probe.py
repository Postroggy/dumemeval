"""Two real upstream product episodes; deterministic tool calls, no model requests."""

import argparse
import json
import os
import urllib.request
from pathlib import Path

from dumemeval.datasets.benchmark import get_benchmark
from dumemeval.metrics.benchmarks.memoryarena_shopping import MemoryArenaShoppingCalculator
from dumemeval.metrics.core.base import MetricInput
from dumemeval.models import SessionOutcome, TaskExecution
from dumemeval.models.environment import ArenaRuntimeConfig
from dumemeval.task_environments.runtime import MemoryArenaRuntime


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ["reference", "python", "assets", "java-home", "output"]:
        parser.add_argument("--" + name, required=True)
    args = parser.parse_args()
    assets, output = Path(args.assets).resolve(), Path(args.output).resolve()
    products = json.loads((assets / "items-first1000-smoke.json").read_text(encoding="utf-8"))
    bought = products[0]
    targets = [products[1], products[0]]
    row = {
        "id": 900002,
        "category": "review_episode_fixture",
        "questions": [f"Product {i + 1}: Buy {product['name']}" for i, product in enumerate(targets)],
        "answers": [{"target_asin": product["asin"], "attributes": []} for product in targets],
    }
    adapter = get_benchmark("memoryarena_shopping")
    task = adapter.build_tasks(adapter.data_type.from_raw([row]))[0]
    config = ArenaRuntimeConfig(
        reference=Path(args.reference),
        python=args.python,
        env_name="webshop",
        timeout_sec=300,
        startup_timeout_sec=300,
        service_env={
            "JAVA_HOME": args.java_home,
            "PATH": str(Path(args.java_home) / "bin") + os.pathsep + os.environ["PATH"],
            "JAVA_TOOL_OPTIONS": "-Xmx1024m -Dfile.encoding=UTF-8",
            "MEMORYARENA_WEBSHOP_DATA_ROOT": str(assets),
            "MEMORYARENA_WEBSHOP_ITEMS_FILE": str(assets / "items-first1000-smoke.json"),
            "MEMORYARENA_WEBSHOP_SEARCH_ROOT": str(assets / "search_engine"),
        },
        env_config={
            "product_catalog_dir": str(assets / "product_catalog"),
            "domain_data_path": str(assets / "domain_data.json"),
        },
    )
    runtime = MemoryArenaRuntime(task, config, output)
    outcomes = []
    try:
        runtime.open()
        for session in task.sessions:
            binding = runtime.begin_session(session)
            assert runtime.gateway is not None
            reset = runtime.evidence[-1]
            assert reset.operation == "reset"
            assert reset.observation["purchases"] == []
            assert reset.observation["target_products"] == [targets[session.id - 1]["asin"]]
            for index, (tool, arguments) in enumerate(
                [
                    ("action", {"action": f"search[{bought['name']}]"}),
                    ("action", {"action": f"click[{bought['asin']}]"}),
                    ("action", {"action": "click[Buy Now]"}),
                    ("submit", {"answer": f"Purchased {bought['asin']}"}),
                ]
            ):
                request = urllib.request.Request(
                    f"http://127.0.0.1:{runtime.gateway.port}/tool",
                    data=json.dumps(
                        {"request_id": f"step-{index}", "tool": tool, "arguments": arguments}
                    ).encode(),
                    headers={
                        "Authorization": "Bearer " + binding.env["DUMEMEVAL_TOOL_TOKEN"],
                        "Content-Type": "application/json",
                    },
                )
                with urllib.request.urlopen(request, timeout=310) as response:
                    json.load(response)
            outcome = runtime.finish_session(session, SessionOutcome(session_id=session.id, success=True))
            assert outcome.success, outcome.error
            outcomes.append(outcome)
            print(f"Product episode {session.id} completed", flush=True)
    finally:
        runtime.close()
    assert runtime.service.process is None or runtime.service.process.poll() is not None
    execution = TaskExecution(
        task_id=task.name, task_name=task.name, memory_backend="none", sessions=outcomes, status="completed"
    )
    scores = MemoryArenaShoppingCalculator().calculate(MetricInput(task=task, execution=execution))
    assert [detail["match_ground_truth"] for detail in scores.details] == [False, True]
    assert scores.values == {"match_ground_truth": 0.5, "overall_success": 0.0}
    trace = json.loads((runtime.directory / "trace.json").read_text(encoding="utf-8"))
    lifecycle = trace["lifecycle"]
    for operation in ["initialize", "reset", "close"]:
        assert sum(event["operation"] == operation for event in lifecycle) == 2
    assert len({outcome.environment.task_id for outcome in outcomes}) == 2
    result = {
        "kind": "official_transport_fixture",
        "benchmark_performance_measured": False,
        "model_requests": 0,
        "reference_revision": config.revision,
        "expected_asins": [product["asin"] for product in targets],
        "actual_asins": [bought["asin"]] * 2,
        "score": scores.model_dump(mode="json"),
        "outcomes": [outcome.model_dump(mode="json") for outcome in outcomes],
        "distinct_environments": 2,
        "empty_purchases_at_each_reset": True,
        "lifecycle": lifecycle,
        "cleanup_status": runtime._cleanup_status,
    }
    (output / "verification.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({"success": True, "scores": scores.values, "distinct_environments": 2}), flush=True)


if __name__ == "__main__":
    main()
