"""Compare test identities and diagnostic multiplicities against the fixed upstream baseline."""

import argparse
import json
import re
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
default_root = Path(__file__).resolve().parent
parser.add_argument("--current", type=Path, default=default_root)
parser.add_argument("--previous", type=Path, default=default_root.parent / "issue4-pr-readiness-20260916")
parser.add_argument("--baseline", type=Path, default=default_root.parent / "issue4-pr-readiness-20260916")
args = parser.parse_args()
root, prior, upstream = args.current, args.previous, args.baseline


def tests(path):
    return {
        node.attrib["classname"] + "::" + node.attrib["name"]: (
            "failed" if node.find("failure") is not None or node.find("error") is not None
            else "skipped" if node.find("skipped") is not None else "passed"
        )
        for node in ET.parse(path).iter("testcase")
    }


def errors(path):
    diagnostics = Counter()
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        match = re.match(r"(.+?):\d+(?::\d+)?: error: (.+)", line)
        if match:
            diagnostics[(match[1].replace("\\", "/"), match[2])] += 1
    return diagnostics


current = tests(root / "pytest-current.xml")
previous = tests(prior / "pytest-current.xml")
baseline = tests(upstream / "pytest-baseline.xml")
related = {name: value for name, value in current.items() if name.startswith(("tests.test_memoryarena_", "tests.test_experiment_controls"))}
official = {name: value for name, value in current.items() if name.startswith("tests.test_memoryarena_official_parity")}
new_tests = sorted(set(current) - set(previous))
current_errors = errors(root / "mypy-current.log")
prior_errors = errors(prior / "mypy-current.log")
baseline_errors = errors(upstream / "mypy-baseline.log")
new_errors = [{"file": file, "diagnostic": diagnostic, "count": count} for (file, diagnostic), count in (current_errors - baseline_errors).items()]
report = {
    "baseline_commit": "37a0e1959e14509898fca856d8fd3fd2a720aefb",
    "previous_commit": "abd6346ee91589ffd2f26bcdd2585f57a474f5d3",
    "current": dict(Counter(current.values())),
    "previous": dict(Counter(previous.values())),
    "baseline": dict(Counter(baseline.values())),
    "related": dict(Counter(related.values())),
    "official_parity": dict(Counter(official.values())),
    "new_regressions": {name: current[name] for name in new_tests},
    "new_failures_from_upstream": sorted(name for name, status in current.items() if status == "failed" and baseline.get(name) != "failed"),
    "new_failures_from_abd6346": sorted(name for name, status in current.items() if status == "failed" and previous.get(name) != "failed"),
    "mypy": {
        "current_errors": sum(current_errors.values()),
        "previous_errors": sum(prior_errors.values()),
        "baseline_errors": sum(baseline_errors.values()),
        "same_diagnostics_as_abd6346": current_errors == prior_errors,
        "new_diagnostics_from_upstream": new_errors,
    },
}
(root / "comparison.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
assert not report["new_failures_from_upstream"] and not report["new_failures_from_abd6346"]
assert not new_errors and current_errors == prior_errors
assert set(related.values()) == {"passed"} and set(official.values()) == {"passed"}
assert all(current[name] == "passed" for name in new_tests)
print(json.dumps({key: value for key, value in report.items() if key != "new_regressions"}, indent=2))
